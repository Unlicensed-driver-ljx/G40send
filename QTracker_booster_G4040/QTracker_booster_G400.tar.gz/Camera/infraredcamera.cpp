#include "infraredcamera.h"

InfraredCamera::InfraredCamera()
{    
    m_img_width = g_param->displayParam.IR_size.width;
    m_img_height = g_param->displayParam.IR_size.height;

    //m_mono16_raw = NULL;
    //m_mono16_raw = new ushort[m_img_width*m_img_height];
    //m_mono16 = Mat(m_img_height,m_img_width,CV_16UC1,m_mono16_raw);
    m_mono16 = Mat::zeros(m_img_height,m_img_width,CV_16UC1);
    m_mono8 = Mat::zeros(m_img_height,m_img_width,CV_8UC1);

    m_buffer_idx = 0;
}

InfraredCamera::~InfraredCamera()
{
    close();

//    if(m_mono16_raw != NULL)
//    {
//        delete[] m_mono16_raw;
//        m_mono16_raw = NULL;
//    }
}

bool InfraredCamera::init()
{
    m_buffer_idx = 0;
    /// close first
    close();
    /// open
    int ret = pxd_PIXCIopen(DRIVERPARMS, "", FORMATFILE);

    if(ret < 0)
    {
        /// error report
        qDebug() << "pxd_PIXCIopen error: " << ret;
        pxd_mesgFault(UNITSMAP);
        return false;
    }

    qDebug() << "pxd_PIXCIopen success: " << ret;

//    if (pxd_eventCapturedFieldCreate(1, SIGUSR1, NULL) >= 0)
//    {
//        printf("Hooked signal upon captured field");
//    }

    pxd_goLivePair(UNITSMAP, 1, 2);
    pxd_mesgFault(UNITSMAP);

    ///info
//    qDebug() << "Image frame buffer memory size: " << pxd_infoMemsize(UNITSMAP)/1024;
//    qDebug() << "Image frame buffers           : " << pxd_imageZdim();
//    qDebug() << "Number of boards              : " << pxd_infoUnits();

//    qDebug() << "Image resolution:";
//    qDebug() << "xdim           = " << pxd_imageXdim();
//    qDebug() << "ydim           = " << pxd_imageYdim();
//    qDebug() << "colors         = " << pxd_imageCdim();
//    qDebug() << "bits per pixel = " << pxd_imageCdim()*pxd_imageBdim();

    qDebug() <<"IR Camera width: "<<pxd_imageXdim() <<", height: " << pxd_imageYdim();

//    int     r;
//    r = pxd_serialConfigure(UNITSMAP, 0,  9600, 8, 0, 1, 0, 0, 0);
//   // qDebug()<<r;
//    if (r < 0)
//        return false;

    return true;
}

void InfraredCamera::close()
{
    stopCapture();
//    quit();
//    wait();
//    deleteLater();
    msleep(10);
    pxd_PIXCIclose();
    //terminate();
}

void InfraredCamera::startCapture()
{
    if(m_bCapture == false)
    {
        m_bCapture = true;
        start(QThread::NormalPriority);
    }
}

void InfraredCamera::stopCapture()
{
    m_bCapture = false;
}

void InfraredCamera::run()
{
    while(true == m_bCapture)
    {
        if(readCurrentFrame() == true)
        {
            if(m_mono16.empty() || m_mono16.cols <= 0 || m_mono16.rows <= 0)
            {
                qDebug() << "InfraredCamera::run m_mono16 size error";
                continue;
            }
            contrastStretch(g_param->displayParam.IR_up_factor, g_param->displayParam.IR_low_factor);
            if(m_mono8.empty())
            {
                qDebug() << "InfraredCamera::run m_mono8 size error";
                continue;
            }
            cv::cvtColor(m_mono8, m_rgb8, COLOR_GRAY2RGB);

            if(g_param->displayParam.imgSource == IR)
            {
                //m_rgb8.copyTo(g_param->imageDisplay);
            }
            else
            {
                m_rgb8.copyTo(g_param->imageDisplay_small);
            }

            g_param->imageProcessQueue_IR.enqueue(m_rgb8);
        }
    }
    stopCapture();
}

bool InfraredCamera::readCurrentFrame()
{
    if (pxd_capturedBuffer(UNITSMAP) == m_buffer_idx)
    {
        //qDebug() << "m_buffer_idx error = " << pxd_capturedBuffer(UNITSMAP);
        return false;
    }
    m_buffer_idx = pxd_capturedBuffer(UNITSMAP);
    //qDebug() << "m_buffer_idx = " << m_buffer_idx;
    char color_space[] = "Grey";

    ushort* mono16_raw = (ushort*)(m_mono16.data);
    if(mono16_raw == NULL)
    {
        qDebug() << "InfraredCamera::readCurrentFrame mono16_raw NULL";
        return false;
    }

    int count = pxd_readushort(UNITSMAP, m_buffer_idx, 0, 0, m_img_width, m_img_height, mono16_raw, m_img_width*m_img_height, color_space);
    if(count != m_img_width*m_img_height)
    {
        qDebug() << "InfraredCamera::readCurrentFrame() pxd_readushort size error";
        return false;
    }
    return true;
}

void InfraredCamera::contrastStretch(float up_factor, float low_factor)
{
    Mat means, stddevs;
    meanStdDev(m_mono16, means, stddevs);
    double upper_bound = means.at<double>(0) + up_factor*stddevs.at<double>(0);
    double lower_bound = means.at<double>(0) - low_factor*stddevs.at<double>(0);

    //qDebug() << upper_bound << ", " << lower_bound;


    if(upper_bound <= lower_bound)
    {
        double tmp = upper_bound;
        lower_bound = upper_bound;
        upper_bound = tmp;
    }
    if(lower_bound < 0)
    {
        lower_bound = 0;
    }
    if(upper_bound > 65535)
    {
        upper_bound = 65535;
    }


    for(int j = 0; j < m_img_height; j++)
    {
        for(int i = 0; i < m_img_width; i++)
        {
            if(m_mono16.at<ushort>(j,i) < lower_bound)
            {
                m_mono8.at<uchar>(j,i) = 0;
            }
            else if(m_mono16.at<ushort>(j,i) > upper_bound)
            {
                m_mono8.at<uchar>(j,i) = 255;
            }
            else
            {
                m_mono8.at<uchar>(j,i) = (uchar)((m_mono16.at<ushort>(j,i) - lower_bound) * 255.0 / (upper_bound - lower_bound + 0.0000001));
            }
        }
    }
}

