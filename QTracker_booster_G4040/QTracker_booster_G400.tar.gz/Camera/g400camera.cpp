#include "g400camera.h"

G400Camera::G400Camera()
{
    m_img_width = g_param->displayParam.VS_size.width;
    m_img_height = g_param->displayParam.VS_size.height;

    m_mono16 = Mat::zeros(g400_width,g400_height,CV_16UC1);
    m_mono16_bkd = Mat::zeros(g400_width,g400_height,CV_16UC1);
    m_mono16_scale = Mat::zeros(m_img_height,m_img_width,CV_16UC1);
    m_mono8 = Mat::zeros(m_img_height,m_img_width,CV_8UC1);

    m_buffer_idx = 0;
    m_remove_bkd = false;
    m_store_bkd_once = false;
}

G400Camera::~G400Camera()
{
    close();
}

bool G400Camera::init()
{
    m_buffer_idx = 0;
    /// close first
    close();
    /// open
    int ret = pxd_PIXCIopen(DRIVERPARMS, "", FORMATFILE);

    if(ret < 0)
    {
        /// error report
        qDebug() << "pxd_PIXCIopen error: " << ret;
        pxd_mesgFault(UNITSMAP);
        return false;
    }

    qDebug() << "pxd_PIXCIopen success: " << ret;

//    if (pxd_eventCapturedFieldCreate(1, SIGUSR1, NULL) >= 0)
//    {
//        printf("Hooked signal upon captured field");
//    }

    pxd_goLivePair(UNITSMAP, 1, 2);
    pxd_mesgFault(UNITSMAP);

    ///info
//    qDebug() << "Image frame buffer memory size: " << pxd_infoMemsize(UNITSMAP)/1024;
//    qDebug() << "Image frame buffers           : " << pxd_imageZdim();
//    qDebug() << "Number of boards              : " << pxd_infoUnits();

//    qDebug() << "Image resolution:";
//    qDebug() << "xdim           = " << pxd_imageXdim();
//    qDebug() << "ydim           = " << pxd_imageYdim();
//    qDebug() << "colors         = " << pxd_imageCdim();
//    qDebug() << "bits per pixel = " << pxd_imageCdim()*pxd_imageBdim();

    qDebug() <<"G400 Visual Camera width: "<<pxd_imageXdim() <<", height: " << pxd_imageYdim();

    if (pxd_serialConfigure(UNITSMAP, 0,  9600, 8, 0, 1, 0, 0, 0) < 0)
    {
        qDebug() << "pxd_serialConfigure error";
        return false;
    }

    return true;
}

void G400Camera::close()
{
    stopCapture();
    msleep(10);
    int ret = 0;
    do
    {
        ret = pxd_PIXCIclose();
        qDebug() << "pxd_PIXCIclose" << ret;
        msleep(50);
    }while(ret >= 0);   
}

void G400Camera::startCapture()
{
    if(m_bCapture == false)
    {
        m_bCapture = true;
        start(QThread::NormalPriority);
    }
}

void G400Camera::stopCapture()
{
    m_bCapture = false;
}

bool G400Camera::readCurrentFrame()
{
    if (pxd_capturedBuffer(UNITSMAP) == m_buffer_idx)
    {
        //qDebug() << "m_buffer_idx error = " << pxd_capturedBuffer(UNITSMAP);
        return false;
    }
    m_buffer_idx = pxd_capturedBuffer(UNITSMAP);
    //qDebug() << "m_buffer_idx = " << m_buffer_idx;
    char color_space[] = "Grey";

    ushort* mono16_raw = (ushort*)(m_mono16.data);
    if(mono16_raw == NULL)
    {
        qDebug() << "G400Camrea::readCurrentFrame mono16_raw NULL";
        return false;
    }

    int count = pxd_readushort(UNITSMAP, m_buffer_idx, 0, 0, g400_width, g400_height, mono16_raw, g400_width*g400_height, color_space);
    if(count != g400_width*g400_height)
    {
        qDebug() << "G400Camrea::readCurrentFrame() pxd_readushort size error";
        return false;
    }
    /// sub bkd 20191205

    if(m_store_bkd_once == true)
    {
        m_store_bkd_once = false;
        m_mono16_bkd = m_mono16.clone();
    }

    if(m_remove_bkd == true)
    {
        cv::absdiff(m_mono16, m_mono16_bkd, m_mono16);
    }

    /// resize
    cv::resize(m_mono16, m_mono16_scale, Size(m_img_width, m_img_height));
    return true;
}

bool G400Camera::setMode(int index)
{
    char buf[6];
    buf[0] = 0x55;
    buf[1] = 0xaa;
    buf[2] = 0x01;
    buf[5] = 0x0d;
    switch(index)
    {
    case 0: /// HG
        buf[3] = 0x00;
        buf[4] = 0x01;
        break;
    case 1: /// LG
        //buf[3] = 0x01;
        //buf[4] = 0x10;
        buf[2] = 0x07;
        buf[3] = 0x01;
        buf[4] = 0x07;
        break;
    case 2: /// STD
        buf[3] = 0x10;
        buf[4] = 0x11;
        break;
    default: /// HG
        buf[3] = 0x00;
        buf[4] = 0x01;
        break;
    }
    if (pxd_serialWrite(UNITSMAP, 0, buf, 0x06) < 0)
    {
        qDebug() << "setMode error " << index;
        return false;
    }
    return true;
}

bool G400Camera::setGain(int index)
{
    char buf[7];
    buf[0] = 0x55;
    buf[1] = 0xaa;
    buf[2] = 0x03;
    buf[6] = 0x0d;

    switch(index)
    {
    case 0: /// 0.66x
        buf[3] = 0x00;
        buf[4] = 0x00;
        break;
    case 1: /// 1.29x
        buf[3] = 0x04;
        buf[4] = 0x04;
        break;
    case 2: /// 1.85x
        buf[3] = 0x01;
        buf[4] = 0x01;
        break;
    case 3: /// 2.49x
        buf[3] = 0x02;
        buf[4] = 0x02;
        break;
    case 4: /// 3.68x
        buf[3] = 0x03;
        buf[4] = 0x03;
        break;
    case 5: /// 3.70x
        buf[3] = 0x05;
        buf[4] = 0x05;
        break;
    case 6: /// 4.95x
        buf[3] = 0x06;
        buf[4] = 0x06;
        break;
    case 7: /// 7.25x
        buf[3] = 0x07;
        buf[4] = 0x07;
        break;
    default:
        buf[3] = 0x04;
        buf[4] = 0x04;
        break;
    }
     buf[5] = ((unsigned char)buf[2] + (unsigned char)buf[3] + (unsigned char)buf[4]) % 256;
     if (pxd_serialWrite(UNITSMAP, 0, buf, 0x07) < 0)
     {
        qDebug() << "G400Camera::setGain error" << index;
        return false;
     }
     return true;
}

bool G400Camera::setExposure(int ms)
{
    char buf[9];
    buf[0] = 0x55;
    buf[1] = 0xAA;
    buf[2] = 0x02;

    ms = ms*39;
    buf[3] = (uchar) ((0xFF000000 & ms) >> 24);
    buf[4] = (uchar) ((0x00FF0000 & ms) >> 16);
    buf[5] = (uchar) ((0x0000FF00 & ms) >> 8);
    buf[6] = (uchar) ((0x000000FF & ms));
    buf[7] = ((unsigned char)buf[2] + (unsigned char)buf[3]+ (unsigned char)buf[4]+ (unsigned char)buf[5]+ (unsigned char)buf[6])%256;

    buf[8] = 0x0D;

    //if (pxd_serialWrite(UNITSMAP, 0, buf, strlen(buf)) < 0)
    if (pxd_serialWrite(UNITSMAP, 0, buf, 0X09) < 0)
    {
        qDebug()<<"G400Camera::setExposure error" << ms;
        return false;
    }
     qDebug()<<"setExposure ok" << ms;
    return true;
}

bool G400Camera::resetCL()
{
   /* char buf[6];
    buf[0] = 0x55;
    buf[1] = 0xaa;
    buf[2] = 0x06;
    buf[3] = 0x00;
    buf[4] = 0x06;
    buf[5] = 0x0d;
    if (pxd_serialWrite(UNITSMAP, 0, buf, strlen(buf)) < 0)
    {
        qDebug()<<"G400Camera::resetCL error";
        return false;
    }
    return true;*/
    static bool flag;
    if(flag)
    {
        char buf[6];
            buf[0] = 0x55;
            buf[1] = 0xaa;
            buf[2] = 0x07;
            buf[3] = 0x00;
            buf[4] = 0x07;
            buf[5] = 0x0d;
            if (pxd_serialWrite(UNITSMAP, 0, buf, 0x06) < 0)
            {
                qDebug()<<"G400Camera::resetCL error";
                return false;
            }
    }
    else
    {
        char buf[6];
            buf[0] = 0x55;
            buf[1] = 0xaa;
            buf[2] = 0x07;
            buf[3] = 0x01;
            buf[4] = 0x08;
            buf[5] = 0x0d;
            if (pxd_serialWrite(UNITSMAP, 0, buf, 0x06) < 0)
            {
                qDebug()<<"G400Camera::resetCL error";
                return false;
            }
    }
    flag = !flag;
        return true;
}

void G400Camera::storeBackground()
{
    m_store_bkd_once = true;
}

void G400Camera::removeBackground(bool flag)
{
    m_remove_bkd = flag;
}

void G400Camera::run()
{
    while(true == m_bCapture)
    {
        if(readCurrentFrame() == true)
        {
            if(m_mono16_scale.empty() || m_mono16_scale.cols <= 0 || m_mono16_scale.rows <= 0)
            {
                qDebug() << "InfraredCamera::run m_mono16 size error";
                continue;
            }

            if(g_param->debugParam.bSaveRawFileOnceGrab == true)
            {
                QDir dir;
                /*if(!dir.exists("/home/nvidia/Pictures"))
                {
                    dir.mkdir("/home/nvidia/Pictures");
                }
                QString path = QString("/home/nvidia/Pictures/%1.tif").arg(cv::getCPUTickCount());*/
                if(!dir.exists("/media/nvidia/92EA-1F0F/Pictures"))
                {
                      dir.mkdir("/media/nvidia/92EA-1F0F/Pictures");
                }
                QString path = QString("/media/nvidia/92EA-1F0F/Pictures/%1.tif").arg(cv::getCPUTickCount());
                //QString path = QString("/home/nvidia/Pictures/%1.tif").arg(QDateTime::currentDateTime().toString("yyyyMMdd_HHmmss.zzz"));
                cv::imwrite(path.toLatin1().data(), m_mono16);

                qDebug() << "1111 ";
                qDebug() << "save raw image in " << path;
            }


            contrastStretch(g_param->displayParam.IR_up_factor, g_param->displayParam.IR_low_factor);
            if(m_mono8.empty())
            {
                qDebug() << "InfraredCamera::run m_mono8 size error";
                continue;
            }
            //cv::cvtColor(m_mono8, m_rgb8, COLOR_GRAY2RGB);
            Mat bb;
            cv::flip(m_mono8, bb, 0);
            cv::cvtColor(bb, m_rgb8, COLOR_GRAY2BGR);
            if(g_param->displayParam.imgSource == VISUAL)
            {
                //m_rgb8.copyTo(g_param->imageDisplay);
            }
            else
            {
                m_rgb8.copyTo(g_param->imageDisplay_small);
            }

            g_param->imageProcessQueue_VS.enqueue(m_rgb8);

            if(g_param->debugParam.bSaveRawFileOnceGrab == true)
            {
                QDir dir;
                if(!dir.exists("/home/nvidia/Pictures"))
                {
                    dir.mkdir("/home/nvidia/Pictures");
                }
                QString path = QString("/home/nvidia/Pictures/%1.jpg").arg(cv::getCPUTickCount());
               /* if(!dir.exists("/media/nvidia/92EA-1F0F/Pictures"))
                {
                     dir.mkdir("/media/nvidia/92EA-1F0F/Pictures");
                }
                QString path = QString("/media/nvidia/92EA-1F0F/Pictures/%1.jpg").arg(cv::getCPUTickCount());*/
                cv::imwrite(path.toLatin1().data(), m_rgb8);

                qDebug() << "save rgb image in " << path;
            }
        }
    }
    stopCapture();
}

void G400Camera::contrastStretch(float up_factor, float low_factor)
{
    Mat means, stddevs;
    meanStdDev(m_mono16_scale, means, stddevs);
    double upper_bound = means.at<double>(0) + up_factor*stddevs.at<double>(0);
    double lower_bound = means.at<double>(0) - low_factor*stddevs.at<double>(0);

    //qDebug() << upper_bound << ", " << lower_bound;


    if(upper_bound <= lower_bound)
    {
        double tmp = upper_bound;
        lower_bound = upper_bound;
        upper_bound = tmp;
    }
    if(lower_bound < 0)
    {
        lower_bound = 0;
    }
    if(upper_bound > 65535)
    {
        upper_bound = 65535;
    }


    for(int j = 0; j < m_img_height; j++)
    {
        for(int i = 0; i < m_img_width; i++)
        {
            if(m_mono16_scale.at<ushort>(j,i) < lower_bound)
            {
                m_mono8.at<uchar>(j,i) = 0;
            }
            else if(m_mono16_scale.at<ushort>(j,i) > upper_bound)
            {
                m_mono8.at<uchar>(j,i) = 255;
            }
            else
            {
                m_mono8.at<uchar>(j,i) = (uchar)((m_mono16_scale.at<ushort>(j,i) - lower_bound) * 255.0 / (upper_bound - lower_bound + 0.0000001));
            }
        }
    }
}

