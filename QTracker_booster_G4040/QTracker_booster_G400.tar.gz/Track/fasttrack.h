#ifndef FASTTRACK_H
#define FASTTRACK_H

#include <QObject>
#include <QThread>
#include <iostream>
#include "Track/KCF_faro/src/kcftracker.hpp"
#include "Detect/YOLO/detectoryologpu.h"
#include "Detect/detectorBlob.h"
#include "Tool/GlobalParameter.h"
#include "Track/eco/eco.hpp"
#include "Track/eco/ecotracker.h"

using namespace std;
using namespace kcf;

class FastTrack : public QThread
{
public:
    FastTrack();
    ~FastTrack();

    bool init();
    void close();
    void startTrack();
    void stopTrack();

private:
    void detect();
    void track();
    void predict();

    void manualIntervention();
    void checkTargetAvailable();
    void checkTrackGate();
    void computeCentriod();
    void changeTrackGate();
protected:
    void run();
private:
    GlobalParameter* g_param;
    bool m_bTrack;
    Mat m_frame;
    long m_loop_track;
    double m_thresh[2]; /// m_thresh[0]: lost ; m_thresh[1]: occlude
    int m_occlude_time; /// 20190717 wangzy 
    int m_count_lost;
    int m_count_occlude;

    kcf::KCFTracker* m_kcf;
    //eco::ECO m_eco;
    ECOTracker m_eco;
    eco::EcoParameters m_parameters;

    DetectorBlob m_yolo;
    DetectResult m_last_yolo_res;

    Mat m_roi_init; /// 20190823 wangzy
};

#endif // FASTTRACK_H
