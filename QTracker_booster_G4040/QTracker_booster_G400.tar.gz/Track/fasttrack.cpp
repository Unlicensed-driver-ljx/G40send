#include "fasttrack.h"

FastTrack::FastTrack()
{
    g_param = GlobalParameter::getInstance();
    m_bTrack = false;
    m_loop_track = 0;
    m_count_lost = 0;
    m_count_occlude = 0;

    m_thresh[0] = g_param->trackParam.thresh_lost;
    m_thresh[1] = g_param->trackParam.thresh_occlude;
    m_occlude_time = g_param->trackParam.occlude_time;

    m_kcf = NULL;
    //m_kcf = new kcf::KCFTracker(true, true, true, true);
}

FastTrack::~FastTrack()
{
    close();
    quit();
    wait();
    deleteLater();
}

bool FastTrack::init()
{
    close();

    m_loop_track = 0;
    m_count_lost = 0;
    m_count_occlude = 0;

    /// kcf
    if(g_param->trackParam.use_scale == true)
    {
        m_kcf = new kcf::KCFTracker(true, true, true, true);
    }
    else
    {
        m_kcf = new kcf::KCFTracker(true, true, false, true);
    }
    m_kcf->setTrainThresh(g_param->trackParam.thresh_occlude);


    m_yolo.init();
    //m_yolo.setTheshold(g_param->trackParam.thresh_conf, g_param->trackParam.thresh_nms);
    m_yolo.setLineMotionTheshold(100, 20, 3);
    m_yolo.setStaticTheshold(100, 6, 30);
    m_yolo.setMaxOutputNum(g_param->trackParam.detect_num);

//    m_yolo.startDetect();
//    m_parameters.useDeepFeature = false;
//    m_parameters.useHogFeature = true;
//    m_parameters.useColorspaceFeature = false;
//    m_parameters.useCnFeature = true;
//    m_parameters.useIcFeature = true;
//    m_parameters.learning_rate = 0.01;
//    m_parameters.projection_reg = 5e-7;
//    m_parameters.init_CG_iter = 10 * 20;
//    m_parameters.CG_forgetting_rate = 60;
//    m_parameters.precond_reg_param = 0.2;
//    m_parameters.reg_window_edge = 4e-3;
    m_parameters.search_area_scale = 3.5;
    m_parameters.max_score_threshhold = g_param->trackParam.thresh_lost;
//    m_parameters.min_image_sample_size = 64*64;
    m_parameters.use_scale_filter = false;
    m_parameters.number_of_scales = 1;
    m_parameters.scale_step = 1.01f;
    m_parameters.useCnFeature = false;
    m_parameters.cn_features.fparams.tablename = "/home/nvidia/wangzy/QTracker_boost/Track/eco/look_tables/CNnorm.txt";

    return true;
}

void FastTrack::close()
{
    stopTrack();
    //terminate();
    if(m_kcf != NULL)
    {
        delete m_kcf;
        m_kcf = NULL;
    }
}

void FastTrack::startTrack()
{
    if (m_bTrack == false)
    {
        m_bTrack = true;
        start(QThread::NormalPriority);
    }
}

void FastTrack::stopTrack()
{
    m_bTrack = false;
}

void FastTrack::detect()
{
    if(m_frame.empty() || m_frame.cols <=0 || m_frame.rows <= 0)
    {
        cout << "FastTrack::detect() error input frame" << endl;
        return;
    }

    m_yolo.detect(m_frame);
    m_yolo.getDetectResult(g_param->yolo_res);
    m_yolo.getDetectResult(m_last_yolo_res);
    g_param->debugParam.detectNum = g_param->yolo_res.boxes.size();

    /// score pos
    float max_conf = 0;
    for(size_t i = 0; i < g_param->yolo_res.prob.size();i++)
    {
        if(max_conf < g_param->yolo_res.prob[i])
        {
            max_conf = g_param->yolo_res.prob[i];
        }
    }
    g_param->trackParam.psr = max_conf;


    /// detect to track
    if(g_param->trackParam.bAutoDetect2Track == true)
    {
        if(g_param->yolo_res.boxes.size() > 0)
        {
            Rect box = g_param->yolo_res.boxes[0];
            if(box.width > 256)
            {
                box.x += (box.width - 256) / 2;
                box.width = 256;
            }
            if(box.height > 256)
            {
                box.y += (box.height - 256) / 2;
                box.height = 256;
            }
            g_param->trackParam.trackGateRoi = box;
            g_param->trackParam.state = TRACK;
            g_param->debugParam.detectNum = 1;

            g_param->yolo_res.boxes.clear();
            g_param->yolo_res.classNamesID.clear();
            g_param->yolo_res.classNamesVec.clear();
            g_param->yolo_res.prob.clear();
        }
    }
}

void FastTrack::track()
{
    /// choose method
    switch (g_param->trackParam.method)
    {
    case TRACK_KCF_HC:

        break;
    case TRACK_KCF:
        if (m_loop_track == 0)
        {
            /// 20190823 wangzy
            if(m_kcf->init(m_frame, g_param->trackParam.trackGateRoi) == true)
            {
                m_roi_init = m_frame(g_param->trackParam.trackGateRoi);
            }
            else
            {
                g_param->trackParam.state = DETECT;
                cout << "track init error, try again" << endl;
            }
        }
        else
        {
            g_param->trackParam.trackGateRoi = m_kcf->update(m_frame);
            g_param->trackParam.objPosPix.x = g_param->trackParam.trackGateRoi.x + g_param->trackParam.trackGateRoi.width / 2;
            g_param->trackParam.objPosPix.y = g_param->trackParam.trackGateRoi.y + g_param->trackParam.trackGateRoi.height / 2;
        }

        break;
    case TRACK_ECO_HC:
        if (m_loop_track == 0)
        {
            /// must be init
            m_eco.init(m_frame, g_param->trackParam.trackGateRoi, m_parameters);
        }
        else
        {
            g_param->trackParam.trackGateRoi = m_eco.update(m_frame);
            g_param->trackParam.objPosPix.x = g_param->trackParam.trackGateRoi.x + g_param->trackParam.trackGateRoi.width / 2;
            g_param->trackParam.objPosPix.y = g_param->trackParam.trackGateRoi.y + g_param->trackParam.trackGateRoi.height / 2;
        }
        break;
    default:
        break;
    }
}

void FastTrack::predict()
{

}

void FastTrack::manualIntervention()
{
    /// 响应操作指令，优先级最高
    if (g_param->trackParam.bManualSelect == true)
    {
        g_param->trackParam.bManualSelect = false; /// 状态复位
        bool bFind = false;


        if(m_last_yolo_res.boxes.size() > 0)
        {
            for(size_t i = 0; i < m_last_yolo_res.boxes.size();i++)
            {
                if(m_last_yolo_res.boxes[i].contains(g_param->displayParam.mouseClickPos))
                {
                    g_param->trackParam.trackGateRoi = m_last_yolo_res.boxes[i];
                    /// 20190726 wangzy
                    if(g_param->trackParam.trackGateRoi.width > g_param->trackParam.trackGateSize.width)
                    {
                        g_param->trackParam.trackGateRoi.width = g_param->trackParam.trackGateSize.width;
                        g_param->trackParam.trackGateRoi.x = g_param->displayParam.mouseClickPos.x - g_param->trackParam.trackGateRoi.width / 2;
                    }
                    if(g_param->trackParam.trackGateRoi.height > g_param->trackParam.trackGateSize.height)
                    {
                        g_param->trackParam.trackGateRoi.height = g_param->trackParam.trackGateSize.height;
                        g_param->trackParam.trackGateRoi.y = g_param->displayParam.mouseClickPos.y - g_param->trackParam.trackGateRoi.height / 2;
                    }


                    bFind = true;
                    break;
                }
            }
        }
        if(bFind == false)
        {
            g_param->trackParam.objPosPix = g_param->displayParam.mouseClickPos; /// 目标位置直接更新
            g_param->trackParam.trackGateRoi.x = g_param->trackParam.objPosPix.x - g_param->trackParam.trackGateSize.width / 2;
            g_param->trackParam.trackGateRoi.y = g_param->trackParam.objPosPix.y - g_param->trackParam.trackGateSize.height / 2;
            g_param->trackParam.trackGateRoi.width = g_param->trackParam.trackGateSize.width; /// default
            g_param->trackParam.trackGateRoi.height = g_param->trackParam.trackGateSize.height;

        }

        checkTrackGate();
        g_param->trackParam.state = TRACK;
        g_param->debugParam.detectNum = 1;
        //g_param->debugParam.avgProcessTime = 0;
        //g_param->debugParam.inputCount = 0;
        //g_param->debugParam.processCount = 0;
        m_loop_track = 0;
        m_count_lost = 0;
        m_count_occlude = 0;

        m_last_yolo_res.boxes.clear();
        m_last_yolo_res.classNamesID.clear();
        m_last_yolo_res.classNamesVec.clear();
        m_last_yolo_res.prob.clear();

        g_param->yolo_res.boxes.clear();
        g_param->yolo_res.classNamesID.clear();
        g_param->yolo_res.classNamesVec.clear();
        g_param->yolo_res.prob.clear();

        m_eco.reset(); /// 20190722 wangzy
    }
}

void FastTrack::checkTargetAvailable()
{
    double psr = 1.0;
    switch (g_param->trackParam.method)
    {
    case TRACK_KCF_HC:

        break;
    case TRACK_KCF:
        //psr = m_kcf->getPSR();
        psr = m_kcf->getPeakValue();
        break;
    case TRACK_ECO_HC:
        psr = m_eco.getScore();
    default:
        break;
    }

    g_param->trackParam.psr = psr;
    //cout << "PSR : " << psr << endl;
    if(psr < g_param->trackParam.thresh_lost)
    {
        cout << m_count_lost <<" someone has blind my eyes, low score:" << psr <<  endl;
        /// lost
        m_count_lost++;
        if(m_count_lost >= 3)
        {
            /// target lost
            g_param->trackParam.state = DETECT;
            m_count_lost = 0;
            cout << "target lost, score:" << psr << endl;
        }

    }
    else if(psr < g_param->trackParam.thresh_occlude)
    {
        cout << m_count_occlude << " someone has covered my eyes, low score:" << psr << endl;
        ///occlusion
        m_count_occlude++;
        if(m_count_occlude >= g_param->trackParam.occlude_time)
        {
            /// target occlusion
            g_param->trackParam.state = DETECT;
            m_count_occlude = 0;
            cout << "target occluded, score:" << psr << endl;
        }
    }
    else
    {
        /// continue recording
        m_count_lost -= 1;
        m_count_occlude -= 1;
        if(m_count_lost < 0)
        {
            m_count_lost = 0;
        }
        if(m_count_occlude < 0)
        {
            m_count_occlude = 0;
        }
    }
}

void FastTrack::checkTrackGate()
{
    Rect2d& gate = g_param->trackParam.trackGateRoi;
    if(gate.width <= 0)
    {
        gate.width = g_param->trackParam.trackGateSize.width;
    }
    if(gate.height <= 0)
    {
        gate.height = g_param->trackParam.trackGateSize.height;
    }

    if(gate.width > g_param->trackParam.trackGateSize.width)
    {
        gate.x += (gate.width - g_param->trackParam.trackGateSize.width) / 2;
        gate.width = g_param->trackParam.trackGateSize.width;
    }
    if(gate.height > g_param->trackParam.trackGateSize.height)
    {
        gate.y += (gate.height - g_param->trackParam.trackGateSize.height) / 2;
        gate.height = g_param->trackParam.trackGateSize.height;
    }


    if(gate.x < 0)
    {
        gate.x = 1;
    }
    if(gate.y < 0)
    {
        gate.y = 1;
    }

    if(gate.x + gate.width > g_param->displayParam.imgSize.width)
    {
        gate.x = g_param->displayParam.imgSize.width - gate.width - 1;
    }
    if(gate.y + gate.height > g_param->displayParam.imgSize.height)
    {
        gate.y = g_param->displayParam.imgSize.height - gate.height - 1;
    }
}

void FastTrack::computeCentriod()
{
    if(g_param->trackParam.state == TRACK)
    {
        Mat roi = m_frame(g_param->trackParam.searchGateRoi).clone();
        /// do filter
        medianBlur(roi, roi, 3);
        /// compute mean

        /// compute centriod
        /// Moment
    }

}

void FastTrack::changeTrackGate()
{
    if(g_param->trackParam.bChangeTrackGateSize == true)
    {
        g_param->trackParam.bChangeTrackGateSize = false;
        /// value changed in io thread
        if(g_param->trackParam.state == TRACK)
        {
           g_param->displayParam.mouseClickPos = g_param->trackParam.objPosPix;
           g_param->trackParam.bManualSelect = true;
        }
    }
}

void FastTrack::run()
{
    double time_profile_counter = 0;
    while(true == m_bTrack)
    {

        /// 获取原始图像
        if(g_param->displayParam.imgSource == VISUAL)
        {
            if (g_param->imageProcessQueue_VS.isEmpty())
            {
                msleep(1);
                continue;
            }
            g_param->imageProcessQueue_VS.dequeue().copyTo(m_frame);
        }
        else
        {
            if (g_param->imageProcessQueue_IR.isEmpty())
            {
                msleep(1);
                continue;
            }
            g_param->imageProcessQueue_IR.dequeue().copyTo(m_frame);
        }

        if (m_frame.empty() || m_frame.cols <= 0 || m_frame.rows <= 0 || m_frame.size <= 0)
        {
            cout << "FastTracker::run() m_frame size error" << endl;
            continue;
        }

        changeTrackGate(); /// 20191026 wangzy

        manualIntervention();

        time_profile_counter = cv::getCPUTickCount();
        /// 各阶段逻辑
        switch (g_param->trackParam.state)
        {
        case IDLE:
            break;
        case DETECT:
            detect();
            m_loop_track = 0;
            break;
        case TRACK:
            track();
            /// if target available
            if(m_loop_track > 3) /// 20190726 wangzy fixed fist frames score equal 0
            {
                checkTargetAvailable();
            }
            m_loop_track++;
            break;
        case PREDICT:
            predict();
            break;
        }
        checkTrackGate();
        //computeCentriod();
        /// pos
        g_param->trackParam.objPosPix.x = g_param->trackParam.trackGateRoi.x + g_param->trackParam.trackGateRoi.width / 2;
        g_param->trackParam.objPosPix.y = g_param->trackParam.trackGateRoi.y + g_param->trackParam.trackGateRoi.height / 2;
        g_param->debugParam.processCount++;

//        if(g_param->trackParam.state != DETECT)
//        {
//            m_frame.copyTo(g_param->imageDisplay);
//        }
        m_frame.copyTo(g_param->imageDisplay);

        time_profile_counter = cv::getCPUTickCount() - time_profile_counter;
        g_param->debugParam.processFPS = 1000 * (cvGetTickFrequency() * 1000) / time_profile_counter;
    }
    /// aviod
    stopTrack();
}

