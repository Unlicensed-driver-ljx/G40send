#-------------------------------------------------
#
# Project created by QtCreator 2019-07-17T14:02:10
#
#-------------------------------------------------

QT       += core gui
QT       += serialport
QT       += network

greaterThan(QT_MAJOR_VERSION, 4): QT += widgets

TARGET = QTracker_booster
TEMPLATE = app
CONFIG += c++11


SOURCES += UI/main.cpp \
    UI/qtracker.cpp \
    Detect/YOLO/detectoryologpu.cpp \
    Camera/camerabase.cpp \
    Camera/visualcamera.cpp \
    Tool/GlobalParameter.cpp \
    UI/smallimagedisplayform.cpp \
    UI/QImageDisplayLabel.cpp \
    IO/serialport.cpp \
    Track/eco/ecotracker.cpp \
    Detect/MRCNN/rcnn.cpp \
    UI/onlinetunedialog.cpp \
    Track/fasttrack.cpp \
    IO/communication.cpp \
    IO/communicationtest.cpp \
    Track/KCF_faro/src/fhog.cpp \
    Track/KCF_faro/src/kcftracker.cpp \
    Camera/g400camera.cpp \
    Camera/infraredcamera.cpp \
    Detect/detectorBlob.cpp

HEADERS  += UI/qtracker.h \
    Detect/YOLO/darknet.h \
    Detect/YOLO/detectoryologpu.h \
    Camera/camerabase.h \
    Camera/visualcamera.h \
    Tool/DataCacheQueue.h \
    Tool/GlobalParameter.h \
    Track/KCF_faro/src/ffttools.hpp \
    Track/KCF_faro/src/fhog.hpp \
    Track/KCF_faro/src/kcftracker.hpp \
    Track/KCF_faro/src/labdata.hpp \
    Track/KCF_faro/src/recttools.hpp \
    Track/KCF_faro/src/tracker.h \
    Track/fasttrack.h \
    UI/smallimagedisplayform.h \
    UI/QImageDisplayLabel.h \
    Track/eco/eco.hpp \
    Track/eco/sse2neon.h \
    Track/eco/debug.hpp \
    Track/eco/feature_extractor.hpp \
    Track/eco/feature_operator.hpp \
    Track/eco/ffttools.hpp \
    Track/eco/fhog.hpp \
    Track/eco/gradient.hpp \
    Track/eco/interpolator.hpp \
    Track/eco/metrics.hpp \
    Track/eco/optimize_scores.hpp \
    Track/eco/parameters.hpp \
    Track/eco/recttools.hpp \
    Track/eco/regularization_filter.hpp \
    Track/eco/sample_update.hpp \
    Track/eco/scale_filter.hpp \
    Track/eco/sse.hpp \
    Track/eco/training.hpp \
    Track/eco/wrappers.hpp \
    IO/serialport.h \
    Track/eco/ecotracker.h \
    Detect/MRCNN/rcnn.h \
    UI/onlinetunedialog.h \
    IO/communication.h \
    IO/communicationtest.h \
    Camera/g400camera.h \
    Camera/infraredcamera.h \
    Detect/detectorBlob.h

FORMS    += UI/qtracker.ui \
    UI/smallimagedisplayform.ui \
    UI/QImageDisplayLabel.ui \
    UI/onlinetunedialog.ui

INCLUDEPATH +=  /usr/local/include  \
                /usr/local/include/opencv  \
                /usr/local/include/opencv2   \
                /usr/local/cuda-9.0/include \
                /usr/local/xclib/inc    \

LIBS += /usr/local/lib/libopencv_video.so  \
        /usr/local/lib/libopencv_objdetect.so \
        /usr/local/lib/libopencv_ml.so  \
        /usr/local/lib/libopencv_cudalegacy.so \
        /usr/local/lib/libopencv_core.so \
        /usr/local/lib/libopencv_features2d.so  \
        /usr/local/lib/libopencv_imgproc.so \
        /usr/local/lib/libopencv_highgui.so \
        /usr/local/lib/libopencv_flann.so   \
        /usr/local/lib/libopencv_calib3d.so   \
        /usr/local/lib/libopencv_videoio.so   \
        /usr/local/lib/libopencv_video.so   \
        /usr/local/lib/libopencv_videostab.so   \
        /usr/local/lib/libopencv_dnn.so   \
        /usr/local/lib/libopencv_imgcodecs.so   \
        /usr/local/lib/libdetect.so \
        /usr/local/lib/libecotracker.so \
#        /usr/local/lib/libkcftracker.so \
        /usr/local/xclib/lib/xclib_aarch64.so
