#include "qtracker.h"
#include "ui_qtracker.h"
#include <QDebug>

QTracker::QTracker(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::QTracker)
{

    ui->setupUi(this);
    g_param = GlobalParameter::getInstance();  
    m_tune_dialog = new OnlineTuneDialog(this);
    m_infrared_camera = new InfraredCamera();
    m_visual_camera = new VisualCamera();
    m_g400_camera = new G400Camera();
    m_comm = new Communication();

    /// 20190724 wangzy
    if(g_param->displayParam.small_win_size > 0)
    {
        m_small_form = new SmallImageDisplayForm(this);
        m_small_form->setWindowFlags(Qt::CustomizeWindowHint|Qt::FramelessWindowHint|Qt::WindowSystemMenuHint|Qt::WindowStaysOnTopHint);
        m_small_form->show();
    }
    else
    {
        m_small_form = NULL;
    }

    m_tune_dialog->setG400CameraPtr(m_g400_camera);

    init();
}

QTracker::~QTracker()
{
    if(m_visual_camera != NULL)
    {
        delete m_visual_camera;
        m_visual_camera = NULL;
    }
    if(m_infrared_camera != NULL)
    {
        delete m_infrared_camera;
        m_infrared_camera = NULL;
    }
    if(m_g400_camera != NULL)
    {
        delete m_g400_camera;
        m_g400_camera = NULL;
    }
    delete ui;
}

void QTracker::resizeEvent(QResizeEvent *)
{
    if(g_param->displayParam.imgSource == VISUAL)
    {
        g_param->displayParam.imgSize = g_param->displayParam.VS_size;
    }
    else
    {
        g_param->displayParam.imgSize = g_param->displayParam.IR_size;
    }
    g_param->displayParam.imgScale.x = ui->labelImageDisplay->width() / (double)g_param->displayParam.imgSize.width;
    g_param->displayParam.imgScale.y = ui->labelImageDisplay->height() / (double)g_param->displayParam.imgSize.height;

    if(m_small_form != NULL && g_param->displayParam.small_win_size > 0)
    {
        switch (g_param->displayParam.small_win_pos) {
        case 0:
            m_small_form->setGeometry(0, 0, m_small_form->width(), m_small_form->height());
            break;
        case 1:
            m_small_form->setGeometry(this->width() - m_small_form->width(), 0, m_small_form->width(), m_small_form->height());
            break;
        case 2:
            m_small_form->setGeometry(this->width() - m_small_form->width(), this->height() - m_small_form->height(), m_small_form->width(), m_small_form->height());
            break;
        case 3:
            m_small_form->setGeometry(0, this->height() - m_small_form->height(), m_small_form->width(), m_small_form->height());
            break;
        default:
            m_small_form->setGeometry(this->width() - m_small_form->width(), 0, m_small_form->width(), m_small_form->height());
            break;
        }

        m_small_form->setVisible(true);
    }
    else
    {
        if(m_small_form != NULL)
        {
            m_small_form->setGeometry(0,0,0,0);
            m_small_form->setVisible(false);
        }
    }
}

void QTracker::closeEvent(QCloseEvent *)
{

    if(m_small_form != NULL)
    {
        m_small_form->stopDisplay();
    }
    ui->labelImageDisplay->stopDisplay();
    m_tune_dialog->close();

    if(m_comm != NULL)
    {
        m_comm->close();
    }
    if(m_visual_camera != NULL)
    {
        m_visual_camera->close();
    }
    if(m_infrared_camera != NULL)
    {
        m_infrared_camera->close();
    }
    if(m_g400_camera != NULL)
    {
        m_g400_camera->close();
        QThread::msleep(50);
    }

    m_track.close();
    QThread::msleep(50);


    qApp->exit();
}

void QTracker::keyPressEvent(QKeyEvent *event)
{
    /// ctrl+M
    if((event->modifiers() == Qt::ControlModifier) && (event->key() == Qt::Key_M))
    {
        g_param->trackParam.bAutoDetect2Track = false;
        g_param->trackParam.state = DETECT;
        cout << "Change Mode: Manual select target" << endl;
    }
    /// ctrl+A
    if((event->modifiers() == Qt::ControlModifier) && (event->key() == Qt::Key_A))
    {
        g_param->trackParam.bAutoDetect2Track = true;
        g_param->trackParam.state = DETECT;
        cout << "Change Mode: Auto select target" << endl;
    }
    /// ctrl+1
    if(event->key() == Qt::Key_1)
    {
        if(g_param->trackParam.state == DETECT && g_param->yolo_res.boxes.size() >= 1)
        {
            g_param->trackParam.bManualSelect = true;
            g_param->displayParam.mouseClickPos.x = g_param->yolo_res.boxes[0].x + g_param->yolo_res.boxes[0].width / 2;
            g_param->displayParam.mouseClickPos.y = g_param->yolo_res.boxes[0].y + g_param->yolo_res.boxes[0].height / 2;
            cout << "Select Target 1" << endl;
        }
    }
    /// ctrl+2
    if(event->key() == Qt::Key_2)
    {
        if(g_param->trackParam.state == DETECT && g_param->yolo_res.boxes.size() >= 2)
        {
            g_param->trackParam.bManualSelect = true;
            g_param->displayParam.mouseClickPos.x = g_param->yolo_res.boxes[1].x + g_param->yolo_res.boxes[1].width / 2;
            g_param->displayParam.mouseClickPos.y = g_param->yolo_res.boxes[1].y + g_param->yolo_res.boxes[1].height / 2;
            cout << "Select Target 2" << endl;
        }
    }
    /// ctrl+3
    if(event->key() == Qt::Key_3)
    {
        if(g_param->trackParam.state == DETECT && g_param->yolo_res.boxes.size() >= 3)
        {
            g_param->trackParam.bManualSelect = true;
            g_param->displayParam.mouseClickPos.x = g_param->yolo_res.boxes[2].x + g_param->yolo_res.boxes[2].width / 2;
            g_param->displayParam.mouseClickPos.y = g_param->yolo_res.boxes[2].y + g_param->yolo_res.boxes[2].height / 2;
            cout << "Select Target 3" << endl;
        }
    }
    /// ctrl+4
    if(event->key() == Qt::Key_4)
    {
        if(g_param->trackParam.state == DETECT && g_param->yolo_res.boxes.size() >= 4)
        {
            g_param->trackParam.bManualSelect = true;
            g_param->displayParam.mouseClickPos.x = g_param->yolo_res.boxes[3].x + g_param->yolo_res.boxes[3].width / 2;
            g_param->displayParam.mouseClickPos.y = g_param->yolo_res.boxes[3].y + g_param->yolo_res.boxes[3].height / 2;
            cout << "Select Target 4" << endl;
        }
    }
    /// ctrl+5
    if(event->key() == Qt::Key_5)
    {
        if(g_param->trackParam.state == DETECT && g_param->yolo_res.boxes.size() >= 5)
        {
            g_param->trackParam.bManualSelect = true;
            g_param->displayParam.mouseClickPos.x = g_param->yolo_res.boxes[4].x + g_param->yolo_res.boxes[4].width / 2;
            g_param->displayParam.mouseClickPos.y = g_param->yolo_res.boxes[4].y + g_param->yolo_res.boxes[4].height / 2;
            cout << "Select Target 5" << endl;
        }
    }
    /// ctrl+6
    if(event->key() == Qt::Key_6)
    {
        if(g_param->trackParam.state == DETECT && g_param->yolo_res.boxes.size() >= 6)
        {
            g_param->trackParam.bManualSelect = true;
            g_param->displayParam.mouseClickPos.x = g_param->yolo_res.boxes[5].x + g_param->yolo_res.boxes[5].width / 2;
            g_param->displayParam.mouseClickPos.y = g_param->yolo_res.boxes[5].y + g_param->yolo_res.boxes[5].height / 2;
            cout << "Select Target 6" << endl;
        }
    }
    /// ctrl+7
    if(event->key() == Qt::Key_7)
    {
        if(g_param->trackParam.state == DETECT && g_param->yolo_res.boxes.size() >= 7)
        {
            g_param->trackParam.bManualSelect = true;
            g_param->displayParam.mouseClickPos.x = g_param->yolo_res.boxes[6].x + g_param->yolo_res.boxes[6].width / 2;
            g_param->displayParam.mouseClickPos.y = g_param->yolo_res.boxes[6].y + g_param->yolo_res.boxes[6].height / 2;
            cout << "Select Target 5" << endl;
        }
    }
    ///ESC
    if(event->key() == Qt::Key_Escape)
    {
        m_tune_dialog->show(); /// 20190723 wangzy
    }
}

void QTracker::init()
{
    if(m_track.init() == true)
    {
        m_track.startTrack();
    }

//    if(m_infrared_camera != NULL && m_infrared_camera->init() == true)
//    {
//        m_infrared_camera->startCapture();
//    }
//    if(m_visual_camera != NULL && m_visual_camera->init() == true)
//    {
//        m_visual_camera->startCapture();
//    }

    if(m_g400_camera != NULL && m_g400_camera->init() == true)
    {
        m_g400_camera->startCapture();
    }

    if(m_comm->init() == false)
    {
        cout << "communication init error"<<endl;
    }


    int disp_fps = (int)(1000.0f / (g_param->displayParam.fps + 0.00000001));
    if(disp_fps < 33)
    {
        disp_fps = 33;
        cout << "UI diplay fps too high, reset to 30Hz"<<endl;
    }
    ui->labelImageDisplay->startDisplay(disp_fps);
    if(m_small_form != NULL)
    {
        m_small_form->startDisplay(disp_fps);
    }
}
