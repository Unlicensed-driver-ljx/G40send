#include "smallimagedisplayform.h"
#include "ui_smallimagedisplayform.h"

SmallImageDisplayForm::SmallImageDisplayForm(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::SmallImageDisplayForm)
{
    ui->setupUi(this);
    g_param = GlobalParameter::getInstance();
    connect(&m_timer, SIGNAL(timeout()), this, SLOT(onTimerDisplay()));
    //setFeatures(QDockWidget::DockWidgetMovable | DockWidgetFloatable);
    //setMinimumSize(640,380);
    setMinimumSize(g_param->displayParam.small_win_size, g_param->displayParam.small_win_size / 16 * 9);
}

SmallImageDisplayForm::~SmallImageDisplayForm()
{
    stopDisplay();
    delete ui;
}

void SmallImageDisplayForm::startDisplay(int ms)
{
    m_timer.stop();
    m_timer.start(ms);
}

void SmallImageDisplayForm::stopDisplay()
{
    m_timer.stop();
}

void SmallImageDisplayForm::updateImage(Mat &frame)
{
    if (frame.channels() == 3)
    {
        try
        {
            if(frame.empty())
            {
                qDebug() << "SmallImageDisplayForm::updateImage frame empty";
                return;
            }
            cv::cvtColor(frame, m_rgbFrame, CV_BGR2RGB);
            m_qimage = QImage((const unsigned char*)(m_rgbFrame.data),
                m_rgbFrame.cols, m_rgbFrame.rows, QImage::Format_RGB888);
        }
        catch (cv::Exception* e)
        {
            qDebug() << "QImageDisplayLabel::updateImage exception " << e->what();
        }
    }
    else
    {
        m_qimage = QImage((const unsigned char*)(frame.data),
            frame.cols, frame.rows, QImage::Format_Indexed8);
    }
    if (!m_qimage.isNull())
    {
        //g_param->debugParam.displayCount++;
        ui->label->setPixmap(QPixmap::fromImage(m_qimage));
    }
    else
    {
        qDebug() << "QImageDisplayLabel::updateImage m_qimage.isNull() ";
    }
}

void SmallImageDisplayForm::onTimerDisplay()
{
    if (g_param->imageDisplay_small.rows > 0 && g_param->imageDisplay_small.cols > 0 && !g_param->imageDisplay_small.empty())
    {
        updateImage(g_param->imageDisplay_small);
    }
}

void SmallImageDisplayForm::mouseDoubleClickEvent(QMouseEvent *)
{
    g_param->trackParam.state = DETECT;
    if(g_param->displayParam.imgSource == VISUAL)
    {
        g_param->displayParam.imgSource = IR;
        g_param->displayParam.imgSize.width = g_param->displayParam.IR_size.width;
        g_param->displayParam.imgSize.height = g_param->displayParam.IR_size.height;
    }
    else
    {
        g_param->displayParam.imgSource = VISUAL;
        g_param->displayParam.imgSize.width = g_param->displayParam.VS_size.width;
        g_param->displayParam.imgSize.height = g_param->displayParam.VS_size.height;
    }
}
