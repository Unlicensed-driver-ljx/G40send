#include "QImageDisplayLabel.h"

QImageDisplayLabel::QImageDisplayLabel(QWidget *parent)
	: QLabel(parent)
{
	ui.setupUi(this);
	g_param = GlobalParameter::getInstance();  
    connect(&m_timer, SIGNAL(timeout()), this, SLOT(onTimerDisplay()));
}

QImageDisplayLabel::~QImageDisplayLabel()
{
	stopDisplay();
}

void QImageDisplayLabel::startDisplay(int ms /*= 40*/)
{
	m_timer.stop();
	m_timer.start(ms);
}

void QImageDisplayLabel::stopDisplay()
{
	m_timer.stop();
}

void QImageDisplayLabel::updateImage(Mat frame)
{
	///// ͼ������
	//rectangle(frame, g_param->trackParam.searchGateRoi, Scalar(0, 255, 255), 2, 8);
	//rectangle(frame, Point(g_param->trackParam.objPosPix.x - g_param->trackParam.trackGateRoi.width / 2,
	//	g_param->trackParam.objPosPix.y - g_param->trackParam.trackGateRoi.height / 2),
	//	Point(g_param->trackParam.objPosPix.x + g_param->trackParam.trackGateRoi.width/2,
	//		g_param->trackParam.objPosPix.y + g_param->trackParam.trackGateRoi.height/2),
	//	Scalar(0, 0, 255), 2, 8);
	/// �漰��Qt��opencvͼ����ʽת��
	//Mat m_rgbFrame;
	//m_rgbFrame.create(1920, 1080, CV_8UC3);

    if(!frame.empty() && frame.size > 0)
    {
       drawDetectBox(frame);
    }

	if (frame.channels() == 3)
	{
		try
		{
			cv::cvtColor(frame, m_rgbFrame, CV_BGR2RGB);
			m_qimage = QImage((const unsigned char*)(m_rgbFrame.data),
				m_rgbFrame.cols, m_rgbFrame.rows, QImage::Format_RGB888);
		}
		catch (cv::Exception* e)
		{
            qDebug() << "QImageDisplayLabel::updateImage exception " << e->what();
		}
	} 
	else
	{
		m_qimage = QImage((const unsigned char*)(frame.data),
			frame.cols, frame.rows, QImage::Format_Indexed8);
	}
	if (!m_qimage.isNull())
	{
		g_param->debugParam.displayCount++; /// ��ʾ����
		/// ������ʾ
        //m_qimageScale = m_qimage.scaled(m_qimage.width()*g_param->displayParam.imgScale, m_qimage.height()*g_param->displayParam.imgScale, Qt::KeepAspectRatio);
		/// ͼ������
        OverlayCharacter();

        this->setPixmap(QPixmap::fromImage(m_qimage));
	} 
	else
	{
        qDebug() << "QImageDisplayLabel::updateImage m_qimage.isNull() ";
	}
}

void QImageDisplayLabel::OverlayCharacter()
{
    m_painter.begin(&m_qimage); /// ��ͼ��ʼ��
	/// ���ٲ���
	int len;
    int len_c;
    m_pen.setWidth(2);
    m_pen.setColor(Qt::green);
    m_painter.setPen(m_pen);
	if (g_param->trackParam.state == TRACK)
	{
        int ws = g_param->trackParam.trackGateRoi.width  / 2 + 2;
        int hs = g_param->trackParam.trackGateRoi.height  / 2 + 2;
		if (hs < 4) hs = 4;
		len = hs / 4 + 1;
        //int x = g_param->trackParam.objPosPix.x ;
        //int y = g_param->trackParam.objPosPix.y ;
        int x = g_param->trackParam.trackGateRoi.x + g_param->trackParam.trackGateRoi.width / 2; /// 20190720 wangzy
        int y = g_param->trackParam.trackGateRoi.y + g_param->trackParam.trackGateRoi.height / 2;

        m_painter.drawLine(x - ws, y - hs, x - ws + len, y - hs);
        m_painter.drawLine(x - ws, y - hs, x - ws, y - hs + len);
        m_painter.drawLine(x - ws, y + hs, x - ws + len, y + hs);
        m_painter.drawLine(x - ws, y + hs, x - ws, y + hs - len);
        m_painter.drawLine(x + ws, y - hs, x + ws - len, y - hs);
        m_painter.drawLine(x + ws, y - hs, x + ws, y - hs + len);
        m_painter.drawLine(x + ws, y + hs, x + ws - len, y + hs);
        m_painter.drawLine(x + ws, y + hs, x + ws, y + hs - len);

       // m_painter.drawLine(g_param->trackParam.objPosPix.x - len, g_param->trackParam.objPosPix.y, g_param->trackParam.objPosPix.x + len, g_param->trackParam.objPosPix.y);
       // m_painter.drawLine(g_param->trackParam.objPosPix.x, g_param->trackParam.objPosPix.y - len, g_param->trackParam.objPosPix.x, g_param->trackParam.objPosPix.y + len);
	}
    /// center cross
    m_pen.setWidth(1);
    m_font.setPointSize(12);
    m_pen.setColor(Qt::red);
    m_painter.setPen(m_pen);
    m_painter.setFont(m_font);
    //m_pen.setColor(Qt::white);
    m_painter.setPen(m_pen);
    len = 128;
    len_c = 64;
    m_painter.drawLine(g_param->displayParam.imgSize.width / 2 - len, g_param->displayParam.imgSize.height / 2, g_param->displayParam.imgSize.width / 2 - len_c, g_param->displayParam.imgSize.height / 2);
    m_painter.drawLine(g_param->displayParam.imgSize.width / 2 + len_c, g_param->displayParam.imgSize.height / 2, g_param->displayParam.imgSize.width / 2 + len, g_param->displayParam.imgSize.height / 2);
    m_painter.drawLine(g_param->displayParam.imgSize.width / 2, g_param->displayParam.imgSize.height / 2 - len, g_param->displayParam.imgSize.width / 2, g_param->displayParam.imgSize.height / 2 - len_c);
    m_painter.drawLine(g_param->displayParam.imgSize.width / 2, g_param->displayParam.imgSize.height / 2 + len_c, g_param->displayParam.imgSize.width / 2, g_param->displayParam.imgSize.height / 2 + len);
    /// info

    //m_pen.setColor(Qt::red);
    //m_painter.setPen(m_pen);
    QString info_1 = QString("  %1      %2      %3      FPS %4      S %5")\
            .arg(g_param->displayParam.imgSource == VISUAL ? "VIS" : "IR")\
            .arg(g_param->trackParam.bAutoDetect2Track ? "A" : "M")\
            .arg(g_param->trackParam.state == DETECT ? "DETECT" : "TRACK")\
            .arg(QString::number(g_param->debugParam.processFPS,'f',1))\
            .arg(QString::number(g_param->trackParam.psr*100,'f',0));
    m_painter.drawText(m_qimage.rect(),Qt::AlignLeft|Qt::AlignTop,info_1);
    QString info_2 = QString("  POS [%1 , %2]   NUM %3")\
            .arg(QString::number(g_param->trackParam.objPosPix.x,'f',2))\
            .arg(QString::number(g_param->trackParam.objPosPix.y,'f',2))\
            .arg(QString::number(g_param->debugParam.detectNum,'f',0));
    m_painter.drawText(m_qimage.rect(),Qt::AlignLeft|Qt::AlignBottom,info_2);

//	if (true)
//	{
//		//m_painter.setPen(QPen(Qt::magenta));
//		m_pen.setWidth(2);
//		m_pen.setColor(Qt::magenta);
//		m_painter.setPen(m_pen);
//		m_painter.drawRect(g_param->trackParam.searchGateRoi.x * g_param->displayParam.imgScale,
//			g_param->trackParam.searchGateRoi.y * g_param->displayParam.imgScale,
//			g_param->trackParam.searchGateRoi.width * g_param->displayParam.imgScale,
//			g_param->trackParam.searchGateRoi.height * g_param->displayParam.imgScale);
//	}
								
    m_painter.end(); ///
}

void QImageDisplayLabel::drawDetectBox(Mat frame)
{
    if(g_param->yolo_res.boxes.size() <= 0)
    {
        return;
    }
    if(frame.channels() == 4)
    {
        cvtColor(frame, frame, COLOR_BGRA2BGR);
    }

    for(size_t i=0;i < g_param->yolo_res.boxes.size();i++)
    {
        if(i >= g_param->yolo_res.classNamesID.size() || i >= g_param->yolo_res.prob.size())
        {
            qDebug() << "detection sync";
            break;
        }
        int offset = g_param->yolo_res.classNamesID[i]*123457 % 80;
        float red = 255*get_color(2,offset,80);
        float green = 255*get_color(1,offset,80);
        float blue = 255*get_color(0,offset,80);

        rectangle(frame,g_param->yolo_res.boxes[i],Scalar(blue,green,red),2);

        string label_prob, label, label_id;
        if(g_param->yolo_res.classNamesID[i] >= (int)g_param->yolo_res.classNamesVec.size())
        {
            label = "Star";
        }
        else
        {
            label_prob = format("%.2f", g_param->yolo_res.prob[i]);
            label = string(g_param->yolo_res.classNamesVec[g_param->yolo_res.classNamesID[i]]) + ":" + label_prob;
        }

        int baseLine = 0;
        Size labelSize = getTextSize(label, FONT_HERSHEY_SIMPLEX, 0.70, 2, &baseLine);
        putText(frame, label, Point(g_param->yolo_res.boxes[i].x + g_param->yolo_res.boxes[i].width - labelSize.width, g_param->yolo_res.boxes[i].y - labelSize.height - 2),
                FONT_HERSHEY_SIMPLEX, 0.70, Scalar(red, blue, green),2);

        label_id = format("%i", i+1 );
        putText(frame, label_id, Point(g_param->yolo_res.boxes[i].x, g_param->yolo_res.boxes[i].y + getTextSize(label_id, FONT_HERSHEY_SIMPLEX, 1.2, 2, &baseLine).height + 2),
                FONT_HERSHEY_SIMPLEX, 1.2, Scalar(red, blue, green),2);
    }


//    g_param->yolo_res.boxes.clear();
//    g_param->yolo_res.classNamesID.clear();
//    g_param->yolo_res.classNamesVec.clear();
//    g_param->yolo_res.prob.clear();
}
void QImageDisplayLabel::drawPred(int classId, float conf, int left, int top, int right, int bottom, Mat &frame)
{
    //Draw a rectangle displaying the bounding box
    rectangle(frame, Point(left, top), Point(right, bottom), Scalar(255, 0, 0), 3);

    //Get the label for the class name and its confidence
    string label = format("%.5f", conf);
    if (!g_param->yolo_res.classNamesVec.empty())
    {
        if(classId < (int)g_param->yolo_res.classNamesVec.size())
        {
            label = g_param->yolo_res.classNamesVec[classId] + ":" + label;
        }
        else
        {
            label = "unknow:" + label;
            //return;
        }
    }

    //Display the label at the top of the bounding box
    int baseLine;
    Size labelSize = getTextSize(label, FONT_HERSHEY_SIMPLEX, 0.5, 1, &baseLine);
    top = max(top, labelSize.height);
    rectangle(frame, Point(left, top - round(1.5*labelSize.height)), Point(left + round(1.5*labelSize.width), top + baseLine), Scalar(255, 255, 255), FILLED);
    putText(frame, label, Point(left, top), FONT_HERSHEY_SIMPLEX, 0.5, Scalar(0, 0, 0), 1);
}

float QImageDisplayLabel::get_color(int c, int x, int max)
{
    float colors[6][3] = { {1,0,1}, {0,0,1},{0,1,1},{0,1,0},{1,1,0},{1,0,0} };
    float ratio = ((float)x/max)*5;
    int i = floor(ratio);
    int j = ceil(ratio);
    ratio -= i;
    float r = (1-ratio) * colors[i][c] + ratio*colors[j][c];
    return r;
}
void QImageDisplayLabel::onTimerDisplay()
{
    if (g_param->imageDisplay.rows > 0 && g_param->imageDisplay.cols > 0)
    {
        updateImage(g_param->imageDisplay);
    }
//    if(!g_param->imageDisplayQueue.isEmpty())
//    {
//        updateImage(g_param->imageDisplayQueue.dequeue());
//    }
}

void QImageDisplayLabel::mousePressEvent(QMouseEvent *event)
{
	if (event->button() == Qt::LeftButton )
	{
        int x = (int)((float)event->pos().x() / g_param->displayParam.imgScale.x);
        int y = (int)((float)event->pos().y() / g_param->displayParam.imgScale.y);
	
		if (x < g_param->displayParam.imgSize.width && y < g_param->displayParam.imgSize.height)
		{
			g_param->displayParam.mouseClickPos.x = x;
			g_param->displayParam.mouseClickPos.y = y;
		}        
	}
}

void QImageDisplayLabel::mouseDoubleClickEvent(QMouseEvent *event)
{
    g_param->displayParam.imgScale.x = width() / (double)g_param->displayParam.imgSize.width;
    g_param->displayParam.imgScale.y = height() / (double)g_param->displayParam.imgSize.height;

	if (event->button() == Qt::LeftButton)
	{
        //int gap_x = geometry().x()
        int x = (int)((float)event->pos().x() / g_param->displayParam.imgScale.x);
        int y = (int)((float)event->pos().y() / g_param->displayParam.imgScale.y);
		if (x < g_param->displayParam.imgSize.width && y < g_param->displayParam.imgSize.height)
		{
			g_param->displayParam.mouseClickPos.x = x;
			g_param->displayParam.mouseClickPos.y = y;

            g_param->trackParam.bManualSelect = true;
            qDebug() << "Maunal click pos: " << x << y;
		}
	}
}
