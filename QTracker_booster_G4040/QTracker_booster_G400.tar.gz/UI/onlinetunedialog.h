#ifndef ONLINETUNEDIALOG_H
#define ONLINETUNEDIALOG_H

#include <QDialog>
#include <QDir>
#include <QFile>
#include "Tool/GlobalParameter.h"
#include "Camera/g400camera.h"

namespace Ui {
class OnlineTuneDialog;
}

class OnlineTuneDialog : public QDialog
{
    Q_OBJECT

public:
    explicit OnlineTuneDialog(QWidget *parent = 0);
    ~OnlineTuneDialog();

    void setG400CameraPtr(G400Camera* g400_camera);
public slots:
    void onG400CameraModeChange(int index);
    void onG400CameraGainChange(int index);
    void onG400CameraSetExp();
    void onG400CameraReset();
    void onG400SaveImageOnceGrab(int state);
    void onG400StoreBackground();
    void onG400SubBackground(int state);

    void onDisplayContrastUpFactor(double val);
    void onDisplayContrastLowFactor(double val);

    void onSaveImage();

    void onTrackChangeThresh_0(double val);
    void onTrackChangeThresh_1(double val);
    void onTrackChangeThresh_3(int val);
    void onTrackChangeTrackGate(int val);
private:
    Ui::OnlineTuneDialog *ui;
    GlobalParameter* g_param;
    G400Camera* m_g400_camera;
};

#endif // ONLINETUNEDIALOG_H
