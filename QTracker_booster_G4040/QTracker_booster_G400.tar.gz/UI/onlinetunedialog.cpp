#include "onlinetunedialog.h"
#include "ui_onlinetunedialog.h"

OnlineTuneDialog::OnlineTuneDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::OnlineTuneDialog)
{
    ui->setupUi(this);
    connect(ui->comboBoxG400Mode, SIGNAL(currentIndexChanged(int)), this, SLOT(onG400CameraModeChange(int)));
    connect(ui->comboBoxG400Gain, SIGNAL(currentIndexChanged(int)), this, SLOT(onG400CameraGainChange(int)));
    connect(ui->pushButtonG400SetExp, SIGNAL(clicked()), this, SLOT(onG400CameraSetExp()));
    connect(ui->pushButtonG400Reset, SIGNAL(clicked()), this, SLOT(onG400CameraReset()));
    connect(ui->checkBoxSaveG400RawImage, SIGNAL(stateChanged(int)), this, SLOT(onG400SaveImageOnceGrab(int)));
    connect(ui->pushButtonG400StoreBkd, SIGNAL(clicked()), this, SLOT(onG400StoreBackground()));
    connect(ui->checkBoxG400SubBkd, SIGNAL(stateChanged(int)), this, SLOT(onG400SubBackground(int)));

    connect(ui->doubleSpinBoxContrastUpFactor, SIGNAL(valueChanged(double)), this, SLOT(onDisplayContrastUpFactor(double)));
    connect(ui->doubleSpinBoxContrastLowFactor, SIGNAL(valueChanged(double)), this, SLOT(onDisplayContrastLowFactor(double)));

    connect(ui->pushButtonSaveImage, SIGNAL(clicked()), this, SLOT(onSaveImage()));

    connect(ui->spinBoxTrackGateSize, SIGNAL(valueChanged(int)), this, SLOT(onTrackChangeTrackGate(int)));
    connect(ui->doubleSpinBoxTrackThresh_0, SIGNAL(valueChanged(double)), this, SLOT(onTrackChangeThresh_0(double)));
    connect(ui->doubleSpinBoxTrackThresh_1, SIGNAL(valueChanged(double)), this, SLOT(onTrackChangeThresh_1(double)));
    connect(ui->spinBoxTrackThresh_3, SIGNAL(valueChanged(int)), this, SLOT(onTrackChangeThresh_3(int)));
    g_param = GlobalParameter::getInstance();
    m_g400_camera = NULL;



    ui->spinBoxTrackGateSize->setValue(g_param->trackParam.trackGateSize.width);
    ui->doubleSpinBoxTrackThresh_0->setValue(g_param->trackParam.thresh_lost);
    ui->doubleSpinBoxTrackThresh_1->setValue(g_param->trackParam.thresh_occlude);
    ui->spinBoxTrackThresh_3->setValue(g_param->trackParam.occlude_time);
}

OnlineTuneDialog::~OnlineTuneDialog()
{
    delete ui;
}

void OnlineTuneDialog::setG400CameraPtr(G400Camera *g400_camera)
{
    m_g400_camera = g400_camera;
}

void OnlineTuneDialog::onG400CameraModeChange(int index)
{
    if(m_g400_camera != NULL)
    {
        m_g400_camera->setMode(index);
    }
}

void OnlineTuneDialog::onG400CameraGainChange(int index)
{
    if(m_g400_camera != NULL)
    {
        m_g400_camera->setGain(index);
    }
}

void OnlineTuneDialog::onG400CameraSetExp()
{
    if(m_g400_camera != NULL)
    {
        m_g400_camera->setExposure(ui->spinBoxG400Exp->value());
    }
}

void OnlineTuneDialog::onG400CameraReset()
{
    if(m_g400_camera != NULL)
    {
        m_g400_camera->resetCL();
    }
}

void OnlineTuneDialog::onG400SaveImageOnceGrab(int state)
{
    g_param->debugParam.bSaveRawFileOnceGrab = (state == 2);
}

void OnlineTuneDialog::onG400StoreBackground()
{
    if(m_g400_camera != NULL)
    {
        m_g400_camera->storeBackground();
    }
}

void OnlineTuneDialog::onG400SubBackground(int state)
{
    if(m_g400_camera != NULL)
    {
        m_g400_camera->removeBackground(state == 2);
    }
}

void OnlineTuneDialog::onDisplayContrastUpFactor(double val)
{
    g_param->displayParam.IR_up_factor = val;
}

void OnlineTuneDialog::onDisplayContrastLowFactor(double val)
{
    g_param->displayParam.IR_low_factor = val;
}

void OnlineTuneDialog::onSaveImage()
{
    QDir dir;
    if(!dir.exists("/home/nvidia/Pictures"))
    {
        dir.mkdir("/home/nvidia/Pictures");
    }
    QString path = QString("/home/nvidia/Pictures/%1.jpg").arg(cv::getCPUTickCount());

    /*if(!dir.exists("/media/nvidia/92EA-1F0F/Pictures"))
        {
            dir.mkdir("/media/nvidia/92EA-1F0F/Pictures");
        }
        QString path = QString("/media/nvidia/92EA-1F0F/Pictures/%1.jpg").arg(cv::getCPUTickCount());*/

    cv::imwrite(path.toLatin1().data(), g_param->imageDisplay);

    qDebug() << "save one image in " << path;
}

void OnlineTuneDialog::onTrackChangeThresh_0(double val)
{
    g_param->trackParam.thresh_lost = val;
}

void OnlineTuneDialog::onTrackChangeThresh_1(double val)
{
    g_param->trackParam.thresh_occlude = val;
}

void OnlineTuneDialog::onTrackChangeThresh_3(int val)
{
    g_param->trackParam.occlude_time = val;
}

void OnlineTuneDialog::onTrackChangeTrackGate(int val)
{
    if( val != g_param->trackParam.trackGateSize.width || val != g_param->trackParam.trackGateSize.height)
    {
        g_param->trackParam.trackGateSize = cv::Size2d(val, val);
        g_param->trackParam.bChangeTrackGateSize = true;
    }
}
