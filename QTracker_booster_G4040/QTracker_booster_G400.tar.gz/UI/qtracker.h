#ifndef QTRACKER_H
#define QTRACKER_H

#include "Track/fasttrack.h"
#include <QMainWindow>
#include <QtCore>
#include "Camera/infraredcamera.h"
#include "Camera/g400camera.h"
#include "Camera/visualcamera.h"
#include "Detect/YOLO/detectoryologpu.h"
#include "UI/smallimagedisplayform.h"
#include "UI/onlinetunedialog.h"
#include "Tool/GlobalParameter.h"
#include "IO/serialport.h"
#include "IO/communication.h"

namespace Ui {
class QTracker;
}

class QTracker : public QMainWindow
{
    Q_OBJECT

public:
    explicit QTracker(QWidget *parent = 0);
    ~QTracker();
protected:
    void resizeEvent(QResizeEvent *);
    void closeEvent(QCloseEvent *);
    void keyPressEvent(QKeyEvent *event);
public slots:
    void init();
private:
    Ui::QTracker *ui;
    SmallImageDisplayForm *m_small_form;
    OnlineTuneDialog* m_tune_dialog;
    GlobalParameter* g_param;

    InfraredCamera* m_infrared_camera;
    VisualCamera* m_visual_camera;
    G400Camera* m_g400_camera;

    FastTrack m_track;
    Communication* m_comm;
};

#endif // QTRACKER_H
