#ifndef RCNN_H
#define RCNN_H


class RCNN
{
public:
    RCNN();
};

#endif // RCNN_H
