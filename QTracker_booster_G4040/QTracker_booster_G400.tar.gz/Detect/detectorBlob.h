#ifndef DETECTORBLOB_H
#define DETECTORBLOB_H
#include <QObject>
#include <opencv2/opencv.hpp>
#include <iostream>
#include <string>
#include <QDebug>
#include <QThread>
#include <QMutex>
#include <QFile>
#include <QtAlgorithms>
#include "Tool/GlobalParameter.h"
#include <vector>
#include <QList>

using namespace std;
using namespace cv;

class DetectorBlob : public QThread
{
public:
    DetectorBlob();
    ~DetectorBlob();
    bool init();
    void close();
    void startDetect();
    void stopDetect();

    void setLineMotionTheshold(int frameNum, int minLineThreshold, int maxdetectLineNum);
    void setStaticTheshold(int frameNum, int staticNum, int maxdetectStaticNum);
    void detect(Mat& frame);
    void getDetectResult(DetectResult& res);

    void setMaxOutputNum(uint n); /// 20190807 wangzy only output n high prob targets
protected:
    void run();
private:
    void imgConvert(const cv::Mat& img, float* dst);
private:
    GlobalParameter* g_param;
    bool m_bDetect;
    float m_confThreshold;
    float m_nmsThreshold;
    int m_classes_num;
    QString m_cfg_path;
    QString m_weight_path;
    QString m_name_path;

    Mat m_rgb_img;
    float* m_input_img; /// input yolo format

    SimpleBlobDetector::Params pDefaultBLOB;
    int m_frameNum;  //blob accumulate frame
    int m_maxdetectLineNum;
    int m_minLineThreshold; //// linear motion accumulate length

    int m_staticNum; //if object > staticNum then object is static
    int m_maxdetectStaticNum;

    QList<vector<KeyPoint>> listVectorPoints;
    Mat numMat;
    DetectResult m_res;
    uint m_max_num; /// 20190807 wangzy
    QMutex m_mutex;
};

#endif // DETECTORBLOB_H
