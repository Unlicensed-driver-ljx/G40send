#include "detectoryologpu.h"

DetectorYoloGPU::DetectorYoloGPU()
{
    g_param = GlobalParameter::getInstance();
    m_bDetect = false;
    m_confThreshold = 0.3f;
    m_nmsThreshold = 0.2f;
    m_classes_num = 80;
    m_max_num = 1000;
    m_net = NULL;
    m_dets = NULL;
    m_input_img = NULL;
}

DetectorYoloGPU::~DetectorYoloGPU()
{
    close();
}

bool DetectorYoloGPU::init()
{
    m_cfg_path = "./cfg/detect.cfg";
    m_weight_path = "./cfg/detect.weights";
    //m_cfg_path = "./cfg/yolov3.cfg";
    //m_weight_path = "./cfg/yolov3.weights";
    m_name_path = "./cfg/detect.names";

    if(!checkFile(m_cfg_path) || !checkFile(m_weight_path) || !checkFile(m_name_path))
    {
        return false;
    }

    m_net = load_network(m_cfg_path.toLatin1().data(),m_weight_path.toLatin1().data(),0); ///加载网络模型
    set_batch_network(m_net, 1);

    ifstream classNamesFile(m_name_path.toLatin1().data());//标签文件coco有80类
    if (classNamesFile.is_open())
    {
        string className = "";
        while (getline(classNamesFile, className))
            m_res.classNamesVec.push_back(className);
    }

    if(m_net != NULL)
    {
        size_t srcSize=m_net->w*m_net->h*3*sizeof(float);
        m_input_img = new float[srcSize];
    }
    else
    {
        return false;
    }
    return true;
}

void DetectorYoloGPU::close()
{
    stopDetect();
    msleep(20);
    free_network(m_net);
    if(m_input_img != NULL)
    {
        delete[] m_input_img;
        m_input_img = NULL;
    }
}

void DetectorYoloGPU::startDetect()
{
    if (m_bDetect == false)
    {
        m_bDetect = true;
        start(QThread::NormalPriority);
    }
}

void DetectorYoloGPU::stopDetect()
{
    m_bDetect = false;
}

void DetectorYoloGPU::setTheshold(float conf, float nms, int classesNum)
{
    if(conf >= 0)
    {
        m_confThreshold = conf;
    }
    if(nms >= 0)
    {
        m_nmsThreshold = conf;
    }
    if(classesNum > 0)
    {
        m_classes_num = classesNum;
    }
}

void DetectorYoloGPU::detect(Mat &frame)
{
    m_mutex.lock();

    Mat frame_det = frame.clone();
    if(frame_det.empty())
    {
        qDebug() << "DetectorYoloGPU::detect frame_det.empty";
        return;
    }
    cv::resize(frame_det, m_rgb_img, Size(m_net->w, m_net->h));
    //cvtColor(m_rgb_img, m_rgb_img, cv::COLOR_BGR2RGB);
    imgConvert(m_rgb_img,m_input_img);//将图像转为yolo形式

    network_predict(m_net,m_input_img);//网络推理
    int nboxes = 0;
    m_dets = get_network_boxes(m_net,m_rgb_img.cols,m_rgb_img.rows,m_confThreshold,0.5,0,1,&nboxes);
    if(m_dets == NULL)
    {
        qDebug() << "DetectorYoloGPU::detect m_dets NULL";
        return;
    }
    if(m_nmsThreshold > 0)
    {
        do_nms_sort(m_dets,nboxes,m_classes_num,m_nmsThreshold);
    }

    m_res.boxes.clear();
    m_res.classNamesID.clear();
    m_res.prob.clear();

    for (int i = 0; i < nboxes; i++)
    {
        bool flag=0;
        int className;
        float prob;
        for(int j=0;j<m_classes_num;j++)
        {
            if(m_dets[i].prob[j] > m_confThreshold)
            {
                if(!flag)
                {
                    flag=1;
                    className=j;
                    prob = m_dets[i].prob[j];
                    break;
                }
            }
        }
        if(flag)
        {
            int left = (m_dets[i].bbox.x - m_dets[i].bbox.w / 2.)*frame.cols;
            int right = (m_dets[i].bbox.x + m_dets[i].bbox.w / 2.)*frame.cols;
            int top = (m_dets[i].bbox.y - m_dets[i].bbox.h / 2.)*frame.rows;
            int bot = (m_dets[i].bbox.y + m_dets[i].bbox.h / 2.)*frame.rows;

            if (left < 0)
                left = 0;
            if (right > frame.cols - 1)
                right = frame.cols - 1;
            if (top < 0)
                top = 0;
            if (bot > frame.rows - 1)
                bot = frame.rows - 1;

            m_res.boxes.push_back(Rect(left, top, fabs(left - right), fabs(top - bot)));
            m_res.classNamesID.push_back(className);
            m_res.prob.push_back(prob);        
        }
    }

    /// sort by prob
    int count = m_res.prob.size();
    for(int i = 0; i < count - 1; i++)
    {
        for(int j = 0; j < count - 1 - i; ++j)
        {
            if(m_res.prob[j] < m_res.prob[j + 1])
            {
                float t_prob = 0;
                t_prob = m_res.prob[j];
                m_res.prob[j] = m_res.prob[j + 1];
                m_res.prob[j + 1] = t_prob;

                Rect t_box = Rect(0,0,0,0);
                t_box = m_res.boxes[j];
                m_res.boxes[j] = m_res.boxes[j + 1];
                m_res.boxes[j + 1] = t_box;

                int t_classNamesID = 0;
                t_classNamesID = m_res.classNamesID[j];
                m_res.classNamesID[j] = m_res.classNamesID[j + 1];
                m_res.classNamesID[j + 1] = t_classNamesID;
            }
        }
    }
    /// remove redundant data
    if(count > m_max_num)
    {
        m_res.boxes.erase(m_res.boxes.begin() + m_max_num, m_res.boxes.end());
        m_res.classNamesID.erase(m_res.classNamesID.begin() + m_max_num, m_res.classNamesID.end());
        m_res.prob.erase(m_res.prob.begin() + m_max_num, m_res.prob.end());
    }
    /// remove overlap
    count = m_res.boxes.size();
    QList<int> r_list;
    r_list.clear();
    for(int i = 0; i < count; i++)
    {
        for(int j = 0; j < count; j++)
        {
            if(i == j) continue;
            if( m_res.boxes[j].contains(Point(m_res.boxes[i].x, m_res.boxes[i].y)) &&
                    m_res.boxes[j].contains(Point(m_res.boxes[i].x + m_res.boxes[i].width, m_res.boxes[i].y + m_res.boxes[i].height)))
            {
                if(!r_list.contains(i))
                {
                    r_list.append(i);
                    break;
                }
            }
        }
    }
    qSort(r_list.begin(), r_list.end(), qGreater<int>());
    for(int i = 0; i < r_list.size(); i++)
    {
        m_res.boxes.erase(m_res.boxes.begin()+r_list.at(i));
        m_res.classNamesID.erase(m_res.classNamesID.begin()+r_list.at(i));
        m_res.prob.erase(m_res.prob.begin()+r_list.at(i));
    }
    /// sort by pos
    count = m_res.boxes.size();
    for(int i = 0; i < count - 1; i++)
    {
        for(int j = 0; j < count - 1 - i; ++j)
        {
            if(m_res.boxes[j].x > m_res.boxes[j + 1].x)
            {
                float t_prob = 0;
                t_prob = m_res.prob[j];
                m_res.prob[j] = m_res.prob[j + 1];
                m_res.prob[j + 1] = t_prob;

                Rect t_box = Rect(0,0,0,0);
                t_box = m_res.boxes[j];
                m_res.boxes[j] = m_res.boxes[j + 1];
                m_res.boxes[j + 1] = t_box;

                int t_classNamesID = 0;
                t_classNamesID = m_res.classNamesID[j];
                m_res.classNamesID[j] = m_res.classNamesID[j + 1];
                m_res.classNamesID[j + 1] = t_classNamesID;
            }
        }
    }
    

    if(m_dets != NULL)
    {
        free_detections(m_dets, nboxes);
        m_dets = NULL;
    }

    m_mutex.unlock();
}


void DetectorYoloGPU::getDetectResult(DetectResult &res)
{
    m_mutex.lock();
    res.boxes.clear();
    res.classNamesID.clear();
    res.prob.clear();
    res.classNamesVec.clear();

    res.classNamesID.assign(m_res.classNamesID.begin(), m_res.classNamesID.end());
    res.prob.assign(m_res.prob.begin(), m_res.prob.end());
    res.classNamesVec.assign(m_res.classNamesVec.begin(), m_res.classNamesVec.end());
    res.boxes.assign(m_res.boxes.begin(), m_res.boxes.end());
    m_mutex.unlock();
}

void DetectorYoloGPU::setMaxOutputNum(uint n)
{
    m_max_num = n;
}

void DetectorYoloGPU::run()
{
    double time_profile_counter = 0;
    Mat frame;
    while(m_bDetect == true)
    {
        time_profile_counter = cv::getCPUTickCount();
        if (g_param->imageDetectQueue.isEmpty())
        {
            msleep(1);
            continue;
        }
        frame = g_param->imageDetectQueue.dequeue();
        detect(frame);
        getDetectResult(g_param->yolo_res);
        time_profile_counter = cv::getCPUTickCount() - time_profile_counter;

        if(g_param->trackParam.state == DETECT)
        {
            frame.copyTo(g_param->imageDisplay);
        }
        //frame.copyTo(g_param->imageDisplay);
        //g_param->imageDisplayQueue.enqueue(frame);

        //g_param->debugParam.processFPS = 1000 * (cvGetTickFrequency() * 1000) / time_profile_counter;
    }
    stopDetect();
}

void DetectorYoloGPU::imgConvert(const Mat &img, float *dst)
{
    uchar *data = img.data;
    int h = img.rows;
    int w = img.cols;
    int c = img.channels();

    for(int k= 0; k < c; ++k)
    {
        for(int i = 0; i < h; ++i)
        {
            for(int j = 0; j < w; ++j)
            {
                dst[k*w*h+i*w+j] = data[(i*w + j)*c + k]/255.0;
            }
        }
    }
}



bool DetectorYoloGPU::checkFile(QString path)
{
    if(!QFile(path).exists())
    {
        qDebug() << path << " file load error!";
        return false;
    }
    else
    {
        return true;
    }
}

