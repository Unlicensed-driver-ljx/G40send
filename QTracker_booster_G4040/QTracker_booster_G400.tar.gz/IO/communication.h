#ifndef COMUNICATION_H
#define COMUNICATION_H

#include <QObject>
#include <QDebug>
#include <QTimer>
#include "serialport.h"
#include "Tool/GlobalParameter.h"

const int RECV_MAIN_CMD = 16;
const int SEND_MAIN_CMD = 12;
const int SEND_MAIN_DATA = 14;

class Communication : public QThread
{
    Q_OBJECT
public:
    explicit Communication(QObject *parent = 0);
    ~Communication();
    bool init();
    void close();
    void startSendData();
    void stopSendData();
public slots:
    bool decodeCommand(QByteArray data);
    void sendData();
protected:
    void run();
private:
    void encodeCommand();
    void encodeData();
    //void encodeData();
private:
    bool m_bSend;
    GlobalParameter* g_param;
    SerialPort* m_port_ttyS0;
    SerialPort* m_port_ttyTHS2;
    float xDegrees_back;
    float yDegrees_back;
    uchar m_cmd_state;
    uchar m_cmd[SEND_MAIN_CMD];
    uchar m_data[SEND_MAIN_DATA];

    QTimer m_timer;
};

#endif // COMUNICATION_H
