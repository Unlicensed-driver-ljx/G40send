#include "communication.h"
#include <QtMath>
#define PixelSize    22
#define FocusLength  154

typedef union {
    float ufloat;
    int  uInt;
}DataUnion;

Communication::Communication(QObject *parent) : QThread(parent)
{
    g_param = GlobalParameter::getInstance();
    m_bSend = false;
    xDegrees_back = 0;
    yDegrees_back = 0;
    m_port_ttyS0 = new SerialPort();
    m_port_ttyTHS2 = new SerialPort();
    connect(m_port_ttyS0, SIGNAL(recvData(QByteArray)), this, SLOT(decodeCommand(QByteArray)));
    connect(&m_timer, SIGNAL(timeout()), this, SLOT(sendData()));
}

Communication::~Communication()
{
    close();
}

bool Communication::init()
{
    if(m_port_ttyS0->init("/dev/ttyUSB0", 115200) == false)
    {
        qDebug() << "m_port_ttyS0->init error";
    }
    if(m_port_ttyTHS2->init("/dev/ttyTHS2", 115200) == false)
    {
        qDebug() << "m_port_ttyTHS2->init error";
    }
    if(m_port_ttyTHS2->isOpen())
    {
        m_timer.start(20);
        //startSendData();
    }
    return true;
}

void Communication::close()
{
    //stopSendData();
    m_timer.stop();
    m_port_ttyS0->close();
    m_port_ttyTHS2->close();
}

void Communication::startSendData()
{
    if (m_bSend == false)
    {
        m_bSend = true;
        start(QThread::NormalPriority);
    }
}

void Communication::stopSendData()
{
    m_bSend = false;
}

bool Communication::decodeCommand(QByteArray data)
{
    /// check size
    if(data.size() != RECV_MAIN_CMD)
    {
        qDebug() << "decodeCommand error size:" << data.size();
        return false;
    }
    /// check head rear
    if(data.at(0) != 0xA5 || data.at(1) != 0xB8 || data.at(RECV_MAIN_CMD - 1) != 0xFE)
    {
        qDebug() << "decodeCommand error head rear:"<< hex << data.at(0) << data.at(1) << data.at(RECV_MAIN_CMD - 1);
        return false;
    }
    /// checksum
    ushort sum = 0;
    for(int i = 2; i < RECV_MAIN_CMD - 3; i++)
    {
        sum += data.at(i);
    }
    ushort checksum = data[14] & 0x000000FF;
    checksum |= ((data[13] << 8) & 0x0000FF00);
    if(checksum != sum)
    {
        qDebug() << "decodeCommand error checksum:" << sum << checksum;
        return false;
    }
    /// check length
    if(data.at(2) != (RECV_MAIN_CMD - 6))
    {
        qDebug() << "decodeCommand error lenght:"<< hex << data.at(2);
        //return false;
    }
    /// command or require
    m_cmd_state = data.at(3);
    if(data.at(3) == 0x55)
    {
        /// VIS IR change
        if(data.at(4) == 0x01)
        {
            /// IR
            g_param->displayParam.imgSource = IR;
            g_param->displayParam.imgSize.width = g_param->displayParam.IR_size.width;
            g_param->displayParam.imgSize.height = g_param->displayParam.IR_size.height;
        }
        else if(data.at(4) == 0x02)
        {
            /// VIS
            g_param->displayParam.imgSource = VISUAL;
            g_param->displayParam.imgSize.width = g_param->displayParam.VS_size.width;
            g_param->displayParam.imgSize.height = g_param->displayParam.VS_size.height;
        }
        else
        {
            qDebug() << "decodeCommand none dev change:" << hex << data.at(4);
        }
        /// Track change
        short x_pos = data[7] & 0x000000FF;
        x_pos |= ((data[6] << 8) & 0x0000FF00);
        short y_pos = data[9] & 0x000000FF;
        y_pos |= ((data[8] << 8) & 0x0000FF00);
        if(data.at(5) == 0x01)
        {
            /// track
            g_param->displayParam.mouseClickPos.x = x_pos;
            g_param->displayParam.mouseClickPos.y = y_pos;

            g_param->trackParam.bManualSelect = true;
            g_param->trackParam.bAutoDetect2Track = false;
        }
        else if(data.at(5) == 0x02)
        {
            /// detect
            g_param->trackParam.state = DETECT;
            g_param->trackParam.bAutoDetect2Track = false;
            int id = data.at(10);
            if(id > 0 && g_param->trackParam.state == DETECT && g_param->yolo_res.boxes.size() >= id)
            {
                g_param->trackParam.bManualSelect = true;
                g_param->displayParam.mouseClickPos.x = g_param->yolo_res.boxes[id - 1].x + g_param->yolo_res.boxes[id - 1].width / 2;
                g_param->displayParam.mouseClickPos.y = g_param->yolo_res.boxes[id - 1].y + g_param->yolo_res.boxes[id - 1].height / 2;
                qDebug() << "Select Target 6" << endl;
            }
        }
        else if(data.at(5) == 0x03)
        {
            /// cancel
            g_param->trackParam.state = DETECT;
            g_param->trackParam.bAutoDetect2Track = false;
        }
        else if(data.at(5) == 0x04) /// 20191030 wangzy
        {
            g_param->trackParam.state = DETECT;
            g_param->trackParam.bAutoDetect2Track = true;
        }
        else
        {
            qDebug() << "decodeCommand none track change:" << hex << data.at(5);
        }

    }
    /// change gate size
    if(data[11] != 0x00)
    {
        int size = (int)data[11] * 8;
        if(g_param->trackParam.trackGateSize.width != size || g_param->trackParam.trackGateSize.height != size)
        {
            g_param->trackParam.trackGateSize = cv::Size2d(size, size);
            g_param->trackParam.bChangeTrackGateSize = true;
        }

    }
    /// return msg
    QThread::msleep(20);
    encodeCommand();
    if(m_port_ttyS0->isOpen())
    {
        m_port_ttyS0->writeData((char*)m_cmd, SEND_MAIN_CMD);
    }
    else
    {
        qDebug() << "decodeCommand error require";
        return false;
    }

    return true;
}

void Communication::sendData()
{
    encodeData();
    m_port_ttyTHS2->writeData((char*)m_data, SEND_MAIN_DATA);
}

void Communication::run()
{
    while(m_bSend)
    {
        encodeData();
        m_port_ttyTHS2->writeData((char*)m_data, SEND_MAIN_DATA);
        msleep(20);
    }
}

void Communication::encodeCommand()
{
    /// set 0
    memset(m_cmd, 0, SEND_MAIN_CMD);
    /// frame head rear
    m_cmd[0] = 0xEB;
    m_cmd[1] = 0x90;
    m_cmd[SEND_MAIN_CMD - 1] = 0xFE;
    /// length
    m_cmd[2] = SEND_MAIN_CMD - 6;
    /// cmd
    m_cmd[3] = m_cmd_state;
    /// IR VIS
    if(g_param->displayParam.imgSource == VISUAL)
    {
        m_cmd[4] = 0x01;
    }
    else if(g_param->displayParam.imgSource == IR)
    {
        m_cmd[4] = 0x02;
    }
    else
    {
        m_cmd[4] = 0x00;
    }
    /// checksum
    ushort sum = 0;
    for(int i = 2; i < SEND_MAIN_CMD - 3; i++)
    {
        sum += m_cmd[i];
    }
    m_cmd[9] = (uchar) ((0x0000FF00 & sum) >> 8);
    m_cmd[10] = (uchar) (0x000000FF & sum);
}

void Communication::encodeData()
{
    /// set 0

    memset(m_data, 0, SEND_MAIN_DATA);
    /// frame head rear //0x23 0x47 0x4a 0x54
    m_data[0] = 0x23;
    m_data[1] = 0x47;
    m_data[2] = 0x4a;
    m_data[3] = 0x54;

    /// pos
    //float x = (g_param->trackParam.objPosPix.x - g_param->displayParam.VS_size.width/2.0) * PixelSize / 1000;
    //float y = (g_param->displayParam.VS_size.height/2.0 - g_param->trackParam.objPosPix.y) * PixelSize / 1000;
    //float xDegrees  = qRadiansToDegrees(qAtan((float)x/(float)FocusLength));
    //float yDegrees  = qRadiansToDegrees(qAtan((float)y/(float)FocusLength));
    float xDegrees = (g_param->trackParam.objPosPix.x - g_param->displayParam.VS_size.width/2.0);
    float yDegrees = (g_param->displayParam.VS_size.height/2.0 - g_param->trackParam.objPosPix.y);
   /*if(xDegrees>1) xDegrees = 1;
   if(xDegrees<-1) xDegrees = -1;
   if(yDegrees>1) yDegrees = 1;
   if(yDegrees<-1) yDegrees = -1;*/

    if(g_param->trackParam.state == TRACK)
    {
        //qDebug("center_x=%d\n",1024);
        //qDebug("delta_x=%d\n",g_param->trackParam.objPosPix.x - g_param->displayParam.VS_size.width/2.0);
        //qDebug("delta_x=%f\n",g_param->trackParam.objPosPix.x - 512.0);
        //qDebug("objPosPix.x=%f\n",g_param->trackParam.objPosPix.x);
        qDebug("xDegree=%f\n",xDegrees);
        DataUnion dataKK;
        //xDegrees = -12.5;
        dataKK.ufloat = xDegrees;
        int speed = dataKK.uInt;
        m_data[4] = speed>>24;
        m_data[5] = speed>>16;
        m_data[6] = speed>>8;
        m_data[7] = speed%256;

        //yDegrees = 12.5;
        qDebug("yDegree=%f\n",yDegrees);
        dataKK.ufloat = yDegrees;
        speed = dataKK.uInt;
        m_data[8]  = speed>>24;
        m_data[9]  = speed>>16;
        m_data[10] =  speed>>8;
        m_data[11] = speed%256;
    }
    m_data[12] = 0x00;
    m_data[13] = 0x56;
}

