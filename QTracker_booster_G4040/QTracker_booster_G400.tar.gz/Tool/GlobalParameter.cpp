#include "GlobalParameter.h"



GlobalParameter* GlobalParameter::getInstance()
{
    static GlobalParameter instance;
    return &instance;
}

void GlobalParameter::resetDebugCount()
{
    debugParam.inputCount = 0;
    debugParam.processCount = 0;
    debugParam.displayCount = 0;
}

void GlobalParameter::allocateMemory()
{
    /// ?????????????
    imageProcessQueue_VS.clear();
    imageProcessQueue_IR.clear();
    imageDetectQueue.clear();
    imageDisplayQueue.clear();
    imageProcessQueue_VS.setMaxCount(2);
    imageProcessQueue_IR.setMaxCount(2);
    imageDetectQueue.setMaxCount(2);
    imageDisplayQueue.setMaxCount(2);
}

void GlobalParameter::loadConfigFile(QString path)
{
    if(!QFile(path).exists())
    {
        qDebug() << path << " file load error!";
        return;
    }
    QSettings set(path, QSettings::IniFormat);

    QStringList group = set.childGroups();
    if(group.size() < 3)
    {
        qDebug() << "load group error";
        return;
    }
    /// detect
    set.beginGroup("Detect");
    trackParam.thresh_conf = set.value("thresh_conf").toFloat();
    trackParam.thresh_nms = set.value("thresh_nms").toFloat();
    trackParam.detect_num = set.value("detect_num").toInt();
    set.endGroup();
    /// display
    set.beginGroup("Display");
    displayParam.VS_size.width = set.value("VS_width").toInt();
    displayParam.VS_size.height = set.value("VS_height").toInt();
    displayParam.IR_size.width = set.value("IR_width").toInt();
    displayParam.IR_size.height = set.value("IR_height").toInt();
    displayParam.IR_up_factor = set.value("IR_up_factor").toFloat();
    displayParam.IR_low_factor = set.value("IR_low_factor").toFloat();
    displayParam.fps = set.value("fps").toInt();
    displayParam.VS_cam_port = set.value("VS_cam_port").toInt();
    displayParam.small_win_size = set.value("small_win_size").toInt();
    displayParam.small_win_pos = set.value("small_win_pos").toInt();
    set.endGroup();
    /// track
    set.beginGroup("Track");
    trackParam.trackGateSize.width = set.value("track_roi_width").toInt();
    trackParam.trackGateSize.height = set.value("track_roi_height").toInt();
    trackParam.thresh_lost = set.value("thresh_0").toDouble();
    trackParam.thresh_occlude = set.value("thresh_1").toDouble();
    trackParam.occlude_time = set.value("thresh_3").toInt();
    trackParam.sn = set.value("sn").toString();
    trackParam.use_scale = set.value("use_scale").toBool();
    trackParam.detect_type = set.value("detect_type").toInt();
    set.endGroup();

}

GlobalParameter::GlobalParameter()
{
    allocateMemory();

    /// ?????????
    memset((void*)&displayParam, 0, sizeof(DisplayParam));
    displayParam.imgScale.x = 1.0;
    displayParam.imgScale.y = 1.0;
    displayParam.imgSource = VISUAL;
    displayParam.imgSize = cv::Size2i(VS_WIDTH, VS_HEIGHT);
    displayParam.IR_size = cv::Size2i(IR_WIDTH, IR_HEIGHT);
    displayParam.VS_size = cv::Size2i(VS_WIDTH, VS_HEIGHT);
    displayParam.fps = 20;
    displayParam.IR_up_factor = 4.0f;
    displayParam.IR_low_factor = 1.0f;
    displayParam.VS_cam_port = 6;
    displayParam.small_win_pos = 1;
    /// ????????????
    trackParam.bManualSelect = false;
    trackParam.bAutoDetect2Track = false;
    trackParam.bChangeTrackGateSize = false;
    trackParam.searchGateSize = cv::Size2d(512,512);
    trackParam.trackGateSize = cv::Size2d(128, 128);
    trackParam.trackGateRoi = cv::Rect2d(0, 0, 0, 0); /// 20190720 wangzy
    trackParam.state = DETECT;
    trackParam.method = TRACK_KCF; /// TRACK_KCF
    trackParam.thresh_lost = 0.1;
    trackParam.thresh_occlude = 0.15;
    trackParam.occlude_time = 60;
    trackParam.detect_num = 7;
    trackParam.thresh_conf = 0.3f;
    trackParam.thresh_nms = 0.2f;
    trackParam.sn = "0000-0000-0000-0000";
    trackParam.detect_type = 2;
    /// ????????????
    resetDebugCount();
    debugParam.bSaveRawFileOnceGrab = false;

    loadConfigFile("./cfg/config.ini");
}


GlobalParameter::~GlobalParameter()
{

}
